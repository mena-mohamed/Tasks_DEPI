﻿using Microsoft.AspNetCore.Mvc;
using MVC_Day2.Data;
using MVC_Day2.Models;
using System.Data.Entity;

namespace MVC_Day2.Controllers
{
    public class StudentController : Controller
    {
            StudentBL studentBL=new StudentBL();

            public IActionResult ShowAll()
            {
                var students = studentBL.GetAll();
                return View(students);
            }


            public IActionResult ShowDetails(int id)
            {
                var student = studentBL.GetById(id);
                if (student == null)
                {
                    return NotFound();
                }
                return View(student);
            }


        
}   }
