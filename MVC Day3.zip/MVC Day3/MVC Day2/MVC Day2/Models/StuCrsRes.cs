﻿namespace MVC_Day2.Models
{
    public class StuCrsRes
    {
        public int StudentId { get; set; }
        public Student Student { get; set; }
        public int CourseId { get; set; }
        public Course Course { get; set; }

        public int Grade { get; set; }

    }
}
