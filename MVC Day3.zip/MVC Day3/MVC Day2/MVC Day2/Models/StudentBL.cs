﻿using MVC_Day2.Data;
using Microsoft.EntityFrameworkCore;

namespace MVC_Day2.Models
{
    public class StudentBL
    {
        MvcDbContext context = new MvcDbContext();

        public List<Student> GetAll()
        {
            return context.Students.ToList();
        }

        public Student? GetById(int id)
        {
            return context.Students.FirstOrDefault(s => s.Id == id);
        }

        public void Add(Student student) 
        {
            context.Students.Add(student);
            context.SaveChanges();
        }

    }
}
