﻿using MVC_Day2.Data;
using System.Data.Entity;

namespace MVC_Day2.Models
{
    public class DepartmentBL
    {
        MvcDbContext context = new MvcDbContext();

        public List<Department> GetAll()
        {
           
             return context.Departments.ToList();
        }

        public Department? GetById(int id)
        {
            return context.Departments.Include(d => d.Students).FirstOrDefault(d => d.Id == id);
        }

        public void AddDept(Department dept)
        {
            context.Add(dept);
            context.SaveChanges();
        }

    }
}
