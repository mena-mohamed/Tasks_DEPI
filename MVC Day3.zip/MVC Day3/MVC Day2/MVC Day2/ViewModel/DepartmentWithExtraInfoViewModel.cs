﻿namespace MVC_Day2.ViewModel
{
    public class DepartmentWithExtraInfoViewModel
    {
        public string DeptName { get; set; }
        public List<string> StudentsNamesOver25 { get; set; } = new List<string>();
        public string DeptState { get; set; }
    }
}
