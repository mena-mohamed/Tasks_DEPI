﻿using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Runtime.Intrinsics.X86;
using System.Text;
using System.Threading;
using System.Threading.Channels;
using System.Xml;
using static System.Net.Mime.MediaTypeNames;

namespace Day3
{
    internal class Program
    {
        class point
        {
            public int value;
        }
        static void Main( )
        {
            #region Problem1
            //Console.WriteLine("Enter your string: ");
            //string name = Console.ReadLine();
            //try
            //{
            //    Console.WriteLine("Enter a number for int.Parse: ");
            //    int X = int.Parse(Console.ReadLine());
            //    Console.WriteLine("Parsed using int.parse: " + X);


            //    Console.WriteLine("Enter a number for convert.ToInt32: ");
            //    int Y = Convert.ToInt32(Console.ReadLine());
            //    Console.WriteLine("Parsed using convert.ToInt32: " + Y);
            //}
            //catch (Exception ex)
            //{
            //    Console.WriteLine("An error is: " + ex.Message);
            //}
            #endregion

            #region Question1
            //Difference between int.Parse and Convert.ToInt32 for null inputs ?

            // int.Parse(null) throws ArgumentNullException.
            // Convert.ToInt32(null) returns 0. 
            #endregion

            #region Problem2
            //Console.WriteLine("Enter a number: ");
            //string input = Console.ReadLine();

            //if(int.TryParse(input,out int x)) 
            //        Console.WriteLine("Valid number: " + x);
            //else
            //        Console.WriteLine("Error: Invalid number"); 
            #endregion

            #region Question2
            //Why is TryParse recommended over Parse in user - facing applications?
            // Because TryParse avoids exceptions and allows safe input checking. 
            #endregion

            #region Problem3
            //object obj;


            //obj = 10;
            //obj = new object();
            //Console.WriteLine(obj.GetHashCode());


            //obj = "menna";
            //obj = new object();
            //Console.WriteLine(obj.GetHashCode());

            //obj = 10.9;
            //obj = new object();
            //Console.WriteLine(obj.GetHashCode()); 
            #endregion

            #region Question3
            //Real purpose of GetHashCode()?
            //   To generate a hash value for use in hashing algorithms and data structures like Hashtable and Dictionary. 
            #endregion

            #region Problem4
            //point x = new point();
            //x.value = 10;

            //point y = x;
            //y.value = 20;

            //Console.WriteLine("new,value of x: " + x.value); 
            #endregion

            #region Question4
            //Significance of reference equality in .NET?
            // It checks whether two references point to the same memory location(same object), not just equal values. 
            #endregion

            #region Problem5
            //string Msg = " Welcome,";
            //Console.WriteLine(Msg);
            //Console.WriteLine("Before: " + Msg.GetHashCode());
            //Msg += "Hi Willy ";
            //Console.WriteLine(Msg); 
            //Console.WriteLine("After: " + Msg.GetHashCode()); 
            #endregion

            #region Question5
            //Why is string immutable in C#?
            //  For security, thread safety, and string interning and stored as and char array. 
            #endregion

            #region Problem6
            //StringBuilder sb;
            //sb = new StringBuilder("Welcome,");
            //Console.WriteLine(sb);  
            //Console.WriteLine("Before: " + sb.GetHashCode());

            //sb.Append("Hi Willy");
            //Console.WriteLine(sb); 
            //Console.WriteLine("After: " + sb.GetHashCode()); 
            #endregion

            #region Question6&7
            //How does StringBuilder address inefficiencies?
            //  StringBuilder modifies the same memory buffer, avoiding creation of multiple string instances.

            //Why faster for large modifications?
            // Because it avoids creating new strings on each change, unlike immutable string.

            #endregion

            #region Problem7
            //Console.Write("Enter first integer: ");
            //int num1=int.Parse( Console.ReadLine());

            //Console.Write("Enter second integer: ");
            //int num2 = int.Parse(Console.ReadLine());

            ////concatenation
            //Console.WriteLine("Sum is: " + num1 + " + "+ num2 + " = " + (num1 + num2));

            ////Composite formatting
            //Console.WriteLine("Sum is: {0} + {1} = {2}", num1, num2, (num1 + num2));

            ////String interpolation 
            //Console.WriteLine($"Sum is: {num1} + {num2} = {num1 + num2}"); 
            #endregion

            #region Question8
            //Most used formatting method and why?
            // String interpolation($"...") because it's clean, readable, and less error-prone. 
            #endregion

            #region Problem8
            //StringBuilder sb = new StringBuilder("Hello");

            //sb.Append(" World");
            //sb.Replace("World", "Menna");
            //sb.Insert(0, "Welcome to ");
            //sb.Remove(0, 11);

            //Console.WriteLine(sb); 
            #endregion

            #region Question9
            //Why is StringBuilder better for modifications?
            // It manages a mutable buffer, reducing memory and processing overhead in frequent changes. 
            #endregion










        }
    }
}
