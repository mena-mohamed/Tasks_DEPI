﻿using API_Day1.Data.DbContexts;
using API_Day1.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace API_Day1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CourseController : ControllerBase
    {
        private readonly SocietyDbContext context;
        public CourseController(SocietyDbContext context)
        {
            this.context = context;
        }

        [HttpGet]
        public IActionResult GetAll()
        {
            List<Course> course = context.Courses.ToList();
            return Ok(course);
        }

        [HttpGet("{id:int}")]
        public IActionResult GetById(int id)
        {
            Course course=context.Courses.FirstOrDefault(C=> C.ID==id);
            if(course!=null) 
                return Ok(course);
            return NotFound();
        }

        [HttpGet("{name:alpha}")]
        public IActionResult GetByName(String name)
        {
            Course course = context.Courses.FirstOrDefault(C => C.Crs_name== name);
            if (course != null)
                return Ok(course);
            return NotFound();
        }

        [HttpPost]
        public IActionResult Add(Course course)
        {
            context.Courses.Add(course);
            context.SaveChanges();
            return CreatedAtAction(nameof(GetById), new { id = course.ID }, course);
        }

        [HttpPut("{id:int}")]
        public IActionResult Update(int id, Course NewCour)
        {
            Course OldCourse = context.Courses.FirstOrDefault(c => c.ID==id);
            if (OldCourse != null)
            {
                OldCourse.Crs_name=NewCour.Crs_name;
                OldCourse.Crs_desc=NewCour.Crs_desc;
                context.SaveChanges();
                return NoContent();
            }
            return NotFound();
        }

        [HttpDelete("{id:int}")]
        public IActionResult Delete(int id)
        {
            Course course=context.Courses.FirstOrDefault(D=> D.ID==id);
            if(course != null)
            {
                context.Remove(course);
                context.SaveChanges() ;
                return NoContent(); 
            }
            return NotFound();
        }
            
    }
}
