﻿using API_Day1.Models;
using Microsoft.EntityFrameworkCore;

namespace API_Day1.Data.DbContexts
{
    public class SocietyDbContext: DbContext
    {
        public DbSet<Course> Courses{ get; set; }

        public SocietyDbContext(DbContextOptions<SocietyDbContext> options) : base(options) { }

    }
}
