﻿using System.ComponentModel.DataAnnotations;

namespace API_Day1.Models
{
    public class Course
    {
       
        public int ID { get; set; }
        [Required]
        [MaxLength(50)]
        public string Crs_name { get; set; }
        [MaxLength(150)]
        public string Crs_desc { get; set; }   
        
        public int? Duration { get; set; }
    }
}
