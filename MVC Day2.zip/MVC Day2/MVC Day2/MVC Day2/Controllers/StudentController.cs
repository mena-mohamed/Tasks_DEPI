﻿using Microsoft.AspNetCore.Mvc;
using MVC_Day2.Data;
using System.Data.Entity;

namespace MVC_Day2.Controllers
{
    public class StudentController : Controller
    {
            private readonly MvcDbContext _context;

            public StudentController(MvcDbContext context)
            {
                _context = context;
            }


            public IActionResult ShowAll()
            {
                var students = _context.Students.ToList();
                return View(students);
            }


            public IActionResult ShowDetails(int id)
            {
                var student = _context.Students.FirstOrDefault(s => s.Id == id);
                if (student == null)
                {
                    return NotFound();
                }
                return View(student);
            }


        
}   }
