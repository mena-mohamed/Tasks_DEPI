﻿using Microsoft.EntityFrameworkCore;
using MVC_Day2.Models;

using Microsoft.EntityFrameworkCore;
namespace MVC_Day2.Data
{
    public class MvcDbContext : DbContext
    {
        public MvcDbContext(DbContextOptions<MvcDbContext> options) : base(options) { }

        //protected MvcDbContext()
        //{
        //}

        //protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        //{
        //    optionsBuilder.UseSqlServer("Data Source=.;Initial Catalog=MVC;Integrated Security=True;Encrypt=False;Trust Server Certificate=True");
        //}

        public DbSet<Department> Departments { get; set; }
        public DbSet<Student> Students { get; set; }
        public DbSet<Teacher> Teachers { get; set; }
        public DbSet<StuCrsRes> StuCrsRes { get; set; }
        public DbSet<Course> Courses { get; set; }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Department>()
                        .HasMany(d => d.Teachers)
                        .WithOne(t => t.Department)
                        .HasForeignKey(t => t.DepartmentId);

            modelBuilder.Entity<Department>()
                        .HasMany(d => d.Courses)
                        .WithOne(c => c.Department)
                        .HasForeignKey(c => c.DepartmentId)
                        .OnDelete(DeleteBehavior.NoAction);

            modelBuilder.Entity<Department>()
                        .HasMany(d => d.Students)
                        .WithOne(s => s.Department)
                        .HasForeignKey(s => s.DepartmentId)
                        .OnDelete(DeleteBehavior.NoAction);


            modelBuilder.Entity<Course>()
                        .HasMany(c => c.Teachers)
                        .WithOne(t => t.Course)
                        .HasForeignKey(t => t.CourseId)
                        .OnDelete(DeleteBehavior.NoAction);

            modelBuilder.Entity<StuCrsRes>()
                        .HasKey(src => new { src.StudentId, src.CourseId });

            modelBuilder.Entity<StuCrsRes>()
                        .HasOne(src => src.Course)
                        .WithMany(c => c.StuCrsRes)
                        .HasForeignKey(src => src.CourseId);

            modelBuilder.Entity<StuCrsRes>()
                        .HasOne(src => src.Student)
                        .WithMany(s => s.StuCrsRes)
                        .HasForeignKey(src => src.StudentId);

            modelBuilder.Entity<Teacher>()
                        .Property(t => t.Salary)
                        .HasColumnType("decimal(18,2)");


        }


    }
}
