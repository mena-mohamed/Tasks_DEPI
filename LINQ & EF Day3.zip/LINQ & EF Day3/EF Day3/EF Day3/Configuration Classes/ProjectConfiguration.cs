﻿using EF_Day3.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EF_Day3.Configuration_Classes
{
    internal class ProjectConfiguration : IEntityTypeConfiguration<Project>
    {
        public void Configure(EntityTypeBuilder<Project> D)
        {
            D.HasKey(x => x.Id);
            D.Property(x => x.Id)
             .UseIdentityColumn(10,10);

            D.Property(x => x.Name)
             .HasColumnType("varchar(50)")
             .HasDefaultValue("OurProject")
             .IsRequired();

            D.Property(x => x.Cost)
             .HasColumnType("money");
            D.HasCheckConstraint("CK_Project_CostRange", "Cost BETWEEN 500000 AND 3500000");
            
        }
    }
}
