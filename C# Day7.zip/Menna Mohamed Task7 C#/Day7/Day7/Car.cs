﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Day7
{
    internal class Car
    {
        public int id { get; set; }
        public string brand { get; set; }
        public double price { get; set; }

        public Car() : this(0, "Unknown", 0.0)
        {
        }

        public Car(int id)
        {
            this.id = id;
            brand = "Unknown";
            price = 0.0;
        }
        public Car(int id, string brand)
        {
            this.id = id;
            this.brand = brand;
            price = 0.0;
        }

        public Car(int id, string brand, double price)
        {
            this.id = id;
            this.price = price;
            this.brand = brand;
        }

        public override string ToString()
        {
            return $"Car: Id={id}, Brand={brand}, Price={price}";
        }
                
    }
}
