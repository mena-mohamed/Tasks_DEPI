﻿using System;
using System.Security.Cryptography;

namespace Day7
{
    internal class Program
    {
        static void Main(string[] args)
        {
            #region Problem1
            //Car car1 = new Car();
            //Car car2 = new Car(1);
            //Car car3 = new Car(2,"BMW");
            //Car car4 = new Car(3, "Toyota", 50000);

            //Console.WriteLine(car1);
            //Console.WriteLine(car2);
            //Console.WriteLine(car3);
            //Console.WriteLine(car4); 
            #endregion

            #region Question1
            //Why does defining a custom constructor suppress the default constructor in C#? 
            // Because the compiler assumes you want full control over object initialization,
            // so it doesn’t generate the default constructor to avoid ambiguity. 
            #endregion

            #region Problem2
            //Calculator cal=new Calculator();
            //Console.WriteLine("Sunm of 2 integers: " + cal.Sum(3,4) );
            //Console.WriteLine("Sum of 3 integers: " + cal.Sum(3,4,5) );
            //Console.WriteLine("Sum of 2 doubles: " + cal.Sum(3.3, 4.5)); 
            #endregion

            #region Question2
            //How does method overloading improve code readability and reusability ?
            // You can use the same method name for similar operations,
            // one class can handle different data type. 
            #endregion

            #region Problem3
            //Child chld=new Child(5,6,7);
            //Console.WriteLine($"X={chld.X} , Y={chld.Y} , Z={chld.Z}"); 
            #endregion

            #region Question3
            //What is the purpose of constructor chaining in inheritance ?
            //    Initialize base class first,Avoid code duplication. 
            #endregion

            #region Problem4
            //Parent p = new Parent(2, 3);
            //Child c = new Child(2, 3, 4);

            //Console.WriteLine("Child product with new: " + c.Product());

            //Parent p2 = c;
            //Console.WriteLine("Parent reference pointing to child: " + p2.Product()); 
            #endregion

            #region Question4
            //How does new differ from override in method overriding? 
            // override:
            //  Redefines a virtual or abstract method in the parent class.
            //  Supports polymorphism: a Parent reference pointing to a Child object calls the Child’s method.

            //new:
            // Hides the parent method without polymorphism.
            // Only a Child reference calls the new method; a Parent reference calls the original Parent method. 
            #endregion

            #region Problem5
            //Parent p = new Parent(2,3);
            //Child c = new Child(2, 3, 4);

            //Console.WriteLine(p);
            //Console.WriteLine(c);

            //Parent p2 = c;
            //Console.WriteLine(p2); 
            #endregion

            #region Question5
            //Why is ToString() often overridden in custom classes?
            //  The original ToString() method in Object returns only the class name.
            //  Overriding it allows a meaningful textual representation of the object’s data, making it easier for printing.  
            #endregion

            #region Problem6
            //Rectangle rec = new Rectangle(3, 5);
            //rec.Draw();
            //Console.WriteLine(rec.CalculationArea()); 
            #endregion

            #region Question6
            //What is the difference between a virtual method and an abstract method in C#? 
            // Virtual method: Has an implementation in the base class and can optionally be overridden in derived classes.
            // Abstract method: Has no implementation in the base class and must be implemented in every derived class. 
            #endregion


        }
    }
}
