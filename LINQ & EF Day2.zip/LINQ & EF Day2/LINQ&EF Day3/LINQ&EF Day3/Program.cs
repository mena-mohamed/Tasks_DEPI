﻿using System;
using System.ComponentModel;
using System.IO;
using System.Linq;
using static LINQ_EF_Day3.ListGenerators;

#region LINQ - Restriction Operators
//1
//var res1 = ProductList.Where((p) => p.UnitsInStock == 0);
//foreach (var unit in res1)
//{
//    Console.WriteLine(unit);
//}

//2
//var res2 = ProductList.Where((p) => p.UnitsInStock > 0 && p.UnitPrice > 3.00M);
//foreach (var item in res2)
//{
//    Console.WriteLine(item);
//}

//3
//string[] Arr = { "zero", "one", "two", "three", "four", "five", "six", "seven", "eight",
//                "nine" };
//var res3 = Arr.Where((name,index) => name.Length <  index);
//foreach (var item in res3)
//{
//    Console.WriteLine(item);
//} 
#endregion

#region LINQ - Element Operators
//var first = ProductList.FirstOrDefault(p => p.UnitsInStock == 0);
//Console.WriteLine(first);

//var first1 = ProductList.FirstOrDefault(p => p.UnitPrice > 1000);
//if (first1 != null) 
//    Console.WriteLine(first1);
//Console.WriteLine("Not found");

//int[] Arr = { 5, 4, 1, 3, 9, 8, 6, 7, 2, 0 };
//var second = Arr.Where( n => n > 5).Skip(1).FirstOrDefault();
//Console.WriteLine(second); 
#endregion

#region LINQ - Aggregate Operators
//1
//int[] Arr = { 5, 4, 1, 3, 9, 8, 6, 7, 2, 0 };
//var con = Arr.Where((p) => p%2!=0);
//foreach (int i in con)
//{
//    Console.WriteLine(i);
//}

//2
//var cust = CustomerList.Select(c => new
//{
//    c.Name,
//    OrderCount = c.Orders.Count(o => o != null)
//});
//foreach (var c in cust)
//{
//    Console.WriteLine($"{c.Name} has {c.OrderCount} orders.");
//}

//3
//var catog = ProductList.GroupBy(p => p.Category)
//                       .Select(p => new
//                       {
//                           Category = p.Key,
//                           Count = p.Count()
//                       });
//foreach (var item in catog) 
//    Console.WriteLine($"{item.Category}: {item.Count} product");

//4
//int[] Arr = { 5, 4, 1, 3, 9, 8, 6, 7, 2, 0 };
//int total = Arr.Sum();
//Console.WriteLine(total);

//5
//string[] words = File.ReadAllLines("dictionary_english.txt");
//int totalchar=words.Sum(x => x.Length);
//Console.WriteLine($"Total Characters= {totalchar}");

//6
//var TotalUnit = ProductList.GroupBy(g => g.Category)
//                           .Select(g => new
//                           {
//                               Category = g.Key,
//                               TotalUnits = g.Sum(p => p.UnitsInStock)
//                           });
//foreach (var unit in TotalUnit)
//{
//    Console.WriteLine(unit);
//}

//7
//string[] words = File.ReadAllLines("dictionary_english.txt");
//int MinLength=words.Min(w => w.Length);
//Console.WriteLine($"Shortest word length= {MinLength}");

//8
//var result = ProductList.GroupBy(g => g.Category)
//                        .Select(g => new
//                        {
//                            Category=g.Key,
//                            Cheapest = g.Min(p => p.UnitPrice)
//                        });
//foreach (var item in result)
//{
//    Console.WriteLine($"{item.Category} => {item.Cheapest}");
//}

//9
//var result = ProductList.GroupBy(g => g.Category)
//                        .Select(g => 
//                        {
//                            var minPrice = g.Min(p => p.UnitPrice);
//                            return new
//                            {
//                                Category = g.Key,
//                                Products = g.Where(p => p.UnitPrice == minPrice)
//                            };
//                        });
//foreach (var group in result)
//{
//    Console.WriteLine($"Category: {group.Category}");
//    foreach (var product in group.Products)
//    {
//        Console.WriteLine($"   {product.ProductName} - {product.UnitPrice}");
//    }
//}

//10
//string[] words = File.ReadAllLines("dictionary_english.txt");
//int MaxLength = words.Max(x => x.Length);
//Console.WriteLine(MaxLength);

//11
//var res = ProductList.GroupBy(g => g.Category)
//                     .Select(g => new
//                     {
//                         Category = g.Key,
//                         MostExpensiveCost = g.Max(p => p.UnitPrice)
//                     });
//foreach (var item in res)
//{
//    Console.WriteLine(item);
//}

//12
//var result = ProductList.GroupBy(g => g.Category)
//                        .Select(g =>
//                        {
//                            var MaxPrice = g.Max(p => p.UnitPrice);
//                            return new
//                            {
//                                Category = g.Key,
//                                Products = g.Where(p =>  p.UnitPrice == MaxPrice)
//                            };
//                        });
//foreach (var group in result) {
//    Console.WriteLine($"Category: {group.Category}");
//    foreach (var product in group.Products)
//        Console.WriteLine($"{product.ProductName} - {product.UnitPrice}");
//}

//13
//string[] words = File.ReadAllLines("dictionary_english.txt");
//var aver=words.Average(x => x.Length);
//Console.WriteLine(aver);

//14
//var result = ProductList.GroupBy(g => g.Category)
//                      .Select(g => new
//                      {
//                          Category = g.Key,
//                          AveragePrice = g.Average(p => p.UnitPrice)
//                      });
//foreach (var item in result)
//{
//    Console.WriteLine(item);
//} 
#endregion

#region LINQ - Ordering Operators 
//1
//var result = ProductList.OrderBy(p => p.ProductName);
//foreach (var item in result) {
//    Console.WriteLine($"{item.ProductName} - {item.UnitPrice}");
//}

//2
//string[] Arr = { "aPPLE", "AbAcUs", "bRaNcH", "BlUeBeRrY", "ClOvEr", "cHeRry" };
//var sortWords = Arr.OrderBy(x => x, StringComparer.OrdinalIgnoreCase);
//foreach (var word in sortWords)
//      Console.WriteLine(word);

//3
//var res = ProductList.OrderByDescending(p => p.UnitsInStock);
//foreach (var unit in res) 
//    Console.WriteLine($"{unit.ProductName} - {unit.UnitsInStock}");

//4
//string[] Arr = { "zero", "one", "two", "three", "four", "five", "six", "seven", "eight","nine" };
//var sortwords=Arr.OrderBy(x => x.Length)
//                 .ThenBy(x => x);
//foreach (var digit in Arr) 
//    Console.WriteLine(digit);

//5
//string[] words = { "aPPLE", "AbAcUs", "bRaNcH", "BlUeBeRrY", "ClOvEr", "cHeRry" };
//var sortwords = words.OrderBy(x => x.Length)
//                     .ThenBy(x => x, StringComparer.OrdinalIgnoreCase);
//foreach(var word in sortwords) 
//    Console.WriteLine(word);

//6
//var result = ProductList.OrderBy(p => p.Category)
//                         .ThenByDescending(p => p.UnitPrice);
//foreach (var item in result) 
//    Console.WriteLine($"{item.Category} - {item.UnitPrice}");

//8
//string[] Arr = { "zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine" };
//var res = Arr.Where(x => x.Length > 1 && x[1] == 'i')
//                    .Reverse();
//foreach (var x in res)
//    Console.WriteLine(x);

#endregion

#region LINQ – Transformation Operators 
//1
//var q1 = ProductList.Select(p => p.ProductName);
//foreach (var p in q1)
//    Console.WriteLine(p);

//2
//string[] words = { "aPPLE", "BlUeBeRrY", "cHeRry" };
//var q2 = words.Select(x => new
//{
//    Upper = x.ToUpper(),
//    Lower = x.ToLower()
//});
//foreach (var word in q2)
//    Console.WriteLine($"Upper: {word.Upper}, Lower: {word.Lower}");

//3
//var q3 = ProductList.Select(p => new
//{
//    p.ProductID,
//    p.ProductName,
//    Price = p.UnitPrice
//});
//foreach (var item in q3)
//    Console.WriteLine(item);

//4
//int[] Arr = { 5, 4, 1, 3, 9, 8, 6, 7, 2, 0 };
//var q4 = Arr.Select((n, i) => new
//{
//    number = n,
//    Inplace = (bool)(n == i)
//});
//foreach (var item in q4)
//    Console.WriteLine($"{item.number}: {item.Inplace}");

//5
//int[] numbersA = { 0, 2, 4, 5, 6, 8, 9 };
//int[] numbersB = { 1, 3, 5, 7, 8 };
//var q5 = numbersA.SelectMany(a => numbersB
//                 .Where(b => a < b)
//                 .Select(b => new
//                 {
//                     A = a,
//                     B = b
//                 }));
//foreach (var pair in q5)
//    Console.WriteLine($"{pair.A} is less than {pair.B}");

//6
//var q6 = CustomerList.SelectMany(c => c.Orders)
//                     .Where(o => o.Total < 500);
//foreach(var o in q6)
//    Console.WriteLine(o);

//7
//var q7 = CustomerList.SelectMany(c => c.Orders)
//                     .Where(o => o.OrderDate.Year >= 1998);
//foreach (var o in q7)
//    Console.WriteLine(o); 
#endregion

#region LINQ - Partitioning Operators 
//1
//var q1 = CustomerList.Where(c => c.City == "Washington")
//                     .SelectMany(c => c.Orders)
//                     .Take(3);
//foreach (var c in q1)
//    Console.WriteLine(c);

//2
//var q2 = CustomerList.Where(c => c.City == "Washington")
//                     .SelectMany(c => c.Orders)
//                     .Skip(3);
//foreach (var c in q2)
//    Console.WriteLine(c);

//3
//int[] numbers = { 5, 4, 1, 3, 9, 8, 6, 7, 2, 0 };
//var q3 = numbers.TakeWhile((num, i) => num >= i);
//Console.WriteLine(string.Join(", ",q3));

//4
//int[] numbers = { 5, 4, 1, 3, 9, 8, 6, 7, 2, 0 };
//var q4 = numbers.SkipWhile(x => x % 3 != 0);
//Console.WriteLine(string.Join(", ",q4));

//5
//int[] numbers = { 5, 4, 1, 3, 9, 8, 6, 7, 2, 0 };
//var q5 = numbers.SkipWhile((n, i) => n >= i);
//Console.WriteLine(string.Join(", ",q5)); 
#endregion

#region LINQ - Quantifiers
//1
//string[] file = File.ReadAllLines("dictionary_english.txt");
//bool HasEi = file.Any(word => word.Contains("ei"));
//Console.WriteLine($"Any word contains 'ei': {HasEi}");

//2
//var q2 = ProductList.GroupBy(p => p.Category)
//                    .Where(g => g.Any(w => w.UnitsInStock == 0));
//foreach (var g in q2)
//{
//    Console.WriteLine($"Category: {g.Key}");
//    foreach (var n in g)
//    { Console.WriteLine(n); }
//}

//3
//var q3 = ProductList.GroupBy(p => p.Category)
//                    .Where(g => g.All(w => w.UnitsInStock > 0));
//foreach (var g in q3)
//{
//    Console.WriteLine($"Category: {g.Key}");
//    foreach(var n in g)
//        { Console.WriteLine(n); }
//} 
#endregion
