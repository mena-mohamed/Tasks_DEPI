use ITI

--1
create or alter function GetMonthNameByDate(@inputdate date)
returns varchar(50)
begin
    declare @name varchar(50)
    select @name = DATENAME(month,@inputdate)
	return @name
end
select dbo.GetMonthNameByDate('2025-07-16')

--2
create function GetNumsBetweenTwoIntger(@start int ,@end int)
returns @numbers table (number int)

as
  begin
    declare @i int = @start
	while @i <= @end
	begin
	  insert into @numbers values(@i)
	  set @i=@i+1
	end
	return 
  end

select * from  GetNumsBetweenTwoIntger(1,7)

--3

create or alter function GetDeptNameByStNUM(@st_id int)
returns  table
as
 return
    (
      select Dept_Name ,FullName=St_Fname+' '+St_Lname
	  from Student S join Department D 
	  on S.Dept_Id = D.Dept_Id
	  where S.St_Id = @st_id
    )
select * from GetDeptNameByStNUM(8)

--4
create or alter function GetMessageByStId(@st_Id int)
returns varchar(max)
as
 begin 
   declare @firstname varchar(max)
   declare @lastname varchar(max)
   declare @msg varchar(max)

   select @firstname=St_Fname , @lastname=St_Lname 
   from Student where St_Id=@st_Id
   if @firstname is NULL and @lastname is NULL
   set @msg = 'First name & Last name is null'
   else if @firstname is null
   set @msg = 'First name is null'
   else if @lastname is null
   set @msg = 'Last name is null'
   else 
   set @msg = 'First & Last name are not null'
   return @msg
 end
 select  dbo.GetMessageByStId(9)

 --5
 create or alter function GetMangerINFormByDateFormat(@format int)
 returns @x table
 (
  DepartmentName varchar(max),
  MangerName varchar(max),
  HiringDate varchar(max)
 )
 as 
   begin
     insert into @x
	 select D.Dept_Name ,S.St_Fname +' '+S.St_Lname AS MangerName,Convert(varchar(max),D.Manager_hiredate,@format) as  hiringdate
	 from Department D join Student S
	 on D.Dept_Id = S.Dept_Id

	 return
  end
  select * from GetMangerINFormByDateFormat(3)

--6
use ITI
GO

use MyCompanycreate or alter function GetStudentInfo (@string varchar(max))
returns @output table (firstname varchar(max))
as
begin

 if @string = 'first name'
 begin
 insert into @output
 select ISNULL(St_Fname,' ') from Student
 end

 if @string = 'last name'
 begin
 insert into @output
 select ISNULL(St_Lname,' ') from Student
 end

 if @string = 'full name'
 begin
 insert into @output
 select ISNULL(St_Fname,' ')+ ' '+ISNULL(St_Lname,' ') from Student
 end
 return
end

select * from  GetStudentInfo('first name')
select * from  GetStudentInfo('last name')
select * from  GetStudentInfo('full name')
-----------------------------------------------
use MyCompany
--7
USE MyCompany
GO

CREATE OR ALTER FUNCTION GetEmployeesByProject (@ProjID INT)
RETURNS @T1 TABLE (
    ID INT,
    FullName VARCHAR(100),
    Gender VARCHAR(100),
    Salary INT,
    projectName VARCHAR(100),
    ProjectID INT
)
AS
BEGIN
    INSERT INTO @T1
    SELECT 
        E.SSN,
        E.Fname + ' ' + E.Lname,
        E.Sex,
		E.Salary,
        P.Pname,
        P.Pnumber
    FROM Employee E
    JOIN Departments D ON D.Dnum = E.Dno
    JOIN Project P ON P.Dnum = D.Dnum
    WHERE P.Pnumber = @ProjID

    RETURN
END

SELECT * FROM GetEmployeesByProject(600)