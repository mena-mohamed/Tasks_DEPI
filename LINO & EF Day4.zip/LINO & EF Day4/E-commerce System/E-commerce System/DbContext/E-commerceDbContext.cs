﻿using E_commerce_System.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace E_commerce_System
{
    internal class E_commerceDbContext : DbContext
    {
        public DbSet<Product> Products { get; set; }
        public DbSet<Category> Categories { get; set; }

        public DbSet<Order> Orders { get; set; }

        public DbSet<Customer> Customers { get; set; }

        public DbSet<OrderDetail> OrderDetails { get; set; }




        protected override void OnConfiguring(DbContextOptionsBuilder modelBuilder)
        {
            modelBuilder.UseSqlServer(@"Server = .; Database = EcommerceDB; Trusted_Connection=True");
        }



        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<OrderDetail>()
                        .HasKey(od => new { od.OrderId, od.ProductId });

            //Category > Product  m:1
            modelBuilder.Entity<Category>()
                        .HasMany(c => c.Products)
                        .WithOne(P => P.Category)
                        .HasForeignKey(o => o.CategoryId);


            //Customer > Order 1:m
            modelBuilder.Entity<Customer>()
                        .HasMany(c => c.Orders)
                        .WithOne(o => o.customer)
                        .HasForeignKey(o => o.CustomerId);


            //Order > Product m:m
            modelBuilder.Entity<OrderDetail>()
                        .HasOne(od => od.Order)
                        .WithMany(o => o.OrderDetails)
                        .HasForeignKey(od => od.OrderId);
           
            modelBuilder.Entity<OrderDetail>()
                        .HasOne(od => od.Product)
                        .WithMany(p => p.OrderDetails)
                        .HasForeignKey(od => od.ProductId);
        }
    }
}
