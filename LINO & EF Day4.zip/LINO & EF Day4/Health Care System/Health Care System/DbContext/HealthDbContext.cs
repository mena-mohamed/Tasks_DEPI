﻿using System;
using Microsoft.EntityFrameworkCore;
using Health_Care_System.Models;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Health_Care_System
{
    internal class HealthDbContext : DbContext
    {
        public DbSet<Patient> Patients;
        public DbSet<Doctor> Doctors;
        public DbSet<Appointment> Appointments;


        protected override void OnConfiguring(DbContextOptionsBuilder modelBuilder)
        {
            modelBuilder.UseSqlServer(@"Server=localhost; Database=HealthDB; Trusted_Connection=True");
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Appointment>()
                        .HasKey(a => new { a.PatientId, a.DoctorId });


           //Patient > Doctor   m:m
           modelBuilder.Entity<Appointment>()
                       .HasOne(a => a.Doctor)
                       .WithMany(d => d.Appointments)
                       .HasForeignKey(a => a.DoctorId);


            modelBuilder.Entity<Appointment>()
                        .HasOne(a => a.Patient)
                        .WithMany(p => p.Appointments)
                        .HasForeignKey(a => a.PatientId);
        }

    }
}
