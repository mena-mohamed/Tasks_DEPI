﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//    o Id, Title, ISBN, AuthorId
//o Many-to-One with Author
//o Many-to-Many with Borrower(through Loan)
// Author
//o Id, Name, BirthDate
//o One-to-Many with Book 
// Borrower
//o Id, Name, MembershipDate
//o Many-to-Many with Book(through Loan)
// Loan
//o BookId, BorrowerId, LoanDate, ReturnDate
//Mapping Relationships: 
// One-to-Many: Author to Book 
// Many-to-Many: Book to Borrower through Loan
namespace Library_System.Models
{
    internal class Borrower
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public DateTime MembershipDate { get; set; }

        public List<Loan> Loans { get; set; }
    }
}
