﻿
using Library_System.Models;
using Microsoft.EntityFrameworkCore;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;

namespace Library_System
{
    internal class LibraryDbContext : DbContext
    {

        public DbSet<Author> Authors { get; set; }
        public DbSet<Book> Books { get; set; }
        public DbSet<Borrower> Borrowers { get; set; }
        public DbSet<Loan> Loans { get; set; }



        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(@"Server =.; Database = LibraryDB; Trusted_Connection = true");
        }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Loan>()
                      .HasKey(l => new { l.BookId, l.BorrowerId });


            //Author > Books  1:m
            modelBuilder.Entity<Author>()
                        .HasMany(a => a.Books)
                        .WithOne(b => b.Author)
                        .HasForeignKey(b => b.AuthorId);


            //Books > Borrower m:m
            modelBuilder.Entity<Loan>()
                        .HasOne(l => l.Book)
                        .WithMany(b => b.Loans)
                        .HasForeignKey(l => l.BookId);

            modelBuilder.Entity<Loan>()
                        .HasOne(l => l.Borrower)
                        .WithMany(b => b.Loans)
                        .HasForeignKey(l => l.BorrowerId);


        }
    }
}
