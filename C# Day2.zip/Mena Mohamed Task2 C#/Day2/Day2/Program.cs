﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Reflection.Metadata;
using static System.Formats.Asn1.AsnWriter;

namespace Day2
{
    class Program
    {
        static void Main( )
        {
            //Answer any problem & question
            #region Problem1
            // Declare and initialize variable x
            //int x = 10;

            // Declare and initialize variable y
            //int y = 20;

            /*
             This line calculates the sum of x and y
             and stores the result in the variable sum
            */
            //int sum = x + y;

            // Output the result to the console
            //Console.WriteLine(sum);

            //Comment: Ctrl + K + C

            //Uncomment: Ctrl + K + U 
            #endregion

            #region Problem2
            //int x = "10";
            //console.WriteLine(x + y);


            //int x = 10; // "10" is a string, should be an integer
            //int y = 5; // y was not declared
            //Console.WriteLine(x + y); // Console should start with 'C'

            //Runtime Error: Occurs while the program is running.Example:
            //int x = 5 / 0; // DivideByZeroException

            //Logical Error: Program runs but gives incorrect result. Example:
            //int y = 2 + 5; // y = 9   
            #endregion

            #region Problem3
            //string FullName = "Menna";
            //int Age = 19;
            //double MonthlySalary = 3500.50;
            //bool IsStudent = true;

            //Why follow naming conventions like PascalCase?

            //Improves readability, maintainability, and team collaboration.
            //Helps distinguish between types, methods, and variables. 
            #endregion

            #region Problem4
            //class Point
            //{
            //public string Name;
            //}

            //point p1 = new point();
            //p1.Name = "Menna";

            //point p2 = p1; // p2 points to the same object as p1
            //p2.Name = "Elsayed";

            //Console.WriteLine(p1.Name); // Output: Elsayed

            //Value Types: Store actual data in stack(e.g., int, float , double).
            //Reference Types: Store reference(pointer) to data in heap(e.g., class, array , object). 
            #endregion

            #region Problem5
            //int x = 15, y = 4;
            //Console.WriteLine($"Sum: {x + y}");
            //Console.WriteLine($"Difference: {x - y}");
            //Console.WriteLine($"Product: {x * y}");
            //Console.WriteLine($"Division: {(double)x / y}");
            //Console.WriteLine($"Remainder: {x % y}");

            //int a = 2, b = 7;
            //Console.WriteLine(a % b);  //output: 2 
            #endregion

            #region Problem6
            //int x = 12;
            //if(x > 10 && x%2==0)
            //Console.WriteLine("Number is greater than 10 and even.");

            //&& (Logical AND): Stops if the first condition is false(short - circuit).
            //& (Bitwise AND) : Always evaluates both sides 
            #endregion

            #region Problem7
            //double input = 15.75;

            //// Implicit casting (not allowed from double to int)
            //int result = (int)input; // Explicit casting

            //Console.WriteLine("Explicit cast: " + result);


            //Question: Why use explicit casting from double to int?
            //Because it may cause data loss, decimal part is discarded. 
            #endregion

            #region Problem8
            //Console.Write("Enter your age: ");
            //string input = Console.ReadLine();

            //int age = int.Parse(input);
            //if (age > 0)
            //     Console.WriteLine("Valid age.");
            //else
            //     Console.WriteLine("Age must be greater than 0.");

            //Question: What exception might occur?
            //  FormatException – if input is not a number.
            //  Can be handled using try-catch as shown above. 
            #endregion

            #region Problem9
            ////prefix  increment then use
            //int x = 1;
            //Console.WriteLine( ++x );      // 2
            ////postfix use then increment
            //Console.WriteLine( x++ );     //2
            //Console.WriteLine( x );       //3

            //Question: What is the value of x?

            // int x = 5;
            // int y = ++x + x++;
            // Step 1: ++x → x becomes 6, returns 6
            // Step 2: x++ → returns 6, then x becomes 7

            // y = 6 + 6 = 12

            // x = 7 
            #endregion


















        }
    }
}
