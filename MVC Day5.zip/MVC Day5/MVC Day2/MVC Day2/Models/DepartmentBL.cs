﻿using MVC_Day2.Data;
using System.Data.Entity;
using MVC_Day2.Controllers;

namespace MVC_Day2.Models
{
    public class DepartmentBL
    {
        MvcDbContext context = new MvcDbContext();

        public List<Department> GetAll()
        {
           
             return context.Departments.ToList();
        }

        public Department? GetById(int deptId)
        {
            return context.Departments.Include(d => d.Students).FirstOrDefault(d => d.Id == deptId);
        }

        public void AddDept(Department dept)
        {
            context.Add(dept);
            context.SaveChanges();
        }

    }
}
