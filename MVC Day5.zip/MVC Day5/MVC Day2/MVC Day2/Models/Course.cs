﻿namespace MVC_Day2.Models
{
    public class Course
    {
        

        public int Id { get; set; }
        public string Name { get; set; }
        public string Degree { get; set; }
        public string MinDegree { get; set; }

        public int DepartmentId { get; set; }
        public Department Department { get; set; }
    

        public List<Teacher> Teachers { get; set; }
        public List<StuCrsRes> StuCrsRes { get; set; }


    }
}
