﻿
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using MVC_Day2.Models;

namespace MVC_Day2.Controllers
{
    public class StudentController : Controller
    {
        StudentBL studentBL = new StudentBL();
        DepartmentBL deptBL = new DepartmentBL();

        public IActionResult Index()
        {
            return View();
        }
        public IActionResult ShowAll(string search, int? deptId, int page = 1, int pageSize = 20)
        {
            var students = studentBL.GetAll();

            if (!string.IsNullOrEmpty(search))
                students = students.Where(s => s.Name.Contains(search, StringComparison.OrdinalIgnoreCase)).ToList();

            if (deptId.HasValue && deptId > 0)
                students = students.Where(s => s.DepartmentId == deptId).ToList();

            int totalCount = students.Count();
            students = students.Skip((page - 1) * pageSize).Take(pageSize).ToList();

            ViewBag.Departments = new SelectList(deptBL.GetAll(), "Id", "Name");
            ViewBag.CurrentDeptId = deptId;
            ViewBag.Search = search;
            ViewBag.CurrentPage = page;
            ViewBag.TotalPages = (int)Math.Ceiling(totalCount / (double)pageSize);

            return View(students);
        }

        public IActionResult ShowDetails(int id)
        {
            var student = studentBL.GetById(id);
            if (student == null) return NotFound();

            return View(student);
        }

        [HttpGet]
        public IActionResult Add()
        {
            ViewData["DeptList"] = new SelectList(deptBL.GetAll(), "Id", "Name");
            // ViewBag.Departments = deptBL.GetAll();
            return View();
        }

        [HttpPost]
        public IActionResult SaveAdd(Student StuSent)
        {
            //if (!string.IsNullOrEmpty(StuSent.Name))
            if (ModelState.IsValid)
            {
                studentBL.Add(StuSent);
                return RedirectToAction("ShowAll");
            }

            ViewData["DeptList"] = new SelectList(deptBL.GetAll(), "Id", "Name");
            return View("Add", StuSent);
        }

        [HttpGet]
        public IActionResult Edit(int id)
        {
            var student = studentBL.GetById(id);
            if (student == null) return NotFound();

            ViewData["DeptList"] = new SelectList(deptBL.GetAll(), "Id", "Name");
            return View(student);
        }

        [HttpPost]
        public IActionResult SaveEdit(Student StuSent)
        {

            if (ModelState.IsValid)
            {
                studentBL.Update(StuSent);
                StudentBL.SaveChanges();
                return RedirectToAction("ShowAll");
            }


            ViewData["DeptList"] = new SelectList(deptBL.GetAll(), "Id", "Name");
            return View("Edit", StuSent);
        }

        [HttpGet]
        public IActionResult Delete(int id)
        {
            var student = studentBL.GetById(id);
            if (student == null) return NotFound();

            return View("WarningDelete", student);
        }

        [HttpPost, ActionName("ConfirmDelete")]
        public IActionResult ConfirmDelete(int id)
        {
            studentBL.Delete(id);
            return RedirectToAction("ShowAll");
        }
    }
}





