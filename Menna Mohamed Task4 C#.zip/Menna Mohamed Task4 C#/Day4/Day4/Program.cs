﻿using System;
using System.Collections.Immutable;
using System.Runtime.Intrinsics.X86;
using System.Threading.Channels;
using System.Xml.Linq;

namespace Day3
{
    internal class Program { 
        enum DayOfWeek { Monday = 1, Tuesday, Wednesday, Thursday, Friday, Saturday, Sunday }
    
        static void Main(string[] args)
        {
            #region Problem1
            //// 1
            //int[] arr1 = new int[3];
            //arr1[0] = 1;
            //arr1[1] = 2;
            //arr1[2] = 3;

            //Console.WriteLine(arr1[0]);
            //Console.WriteLine(arr1[1]);
            //Console.WriteLine(arr1[2]);

            //// 2
            //int [] arr2 = new int[ ] { 1, 2, 3 };
            //for (int i = 0; i < arr2.Length; i++)
            //{
            //    Console.WriteLine(arr2[i]);
            //}

            //// 3 syntax suger
            //int[] arr3 = { 1, 2, 3 };
            //foreach (int i in arr3)
            //{
            //    Console.WriteLine(i);
            //}

            //try
            //{
            //    Console.WriteLine(arr1[4]);
            //}
            //catch(IndexOutOfRangeException ex)
            //{
            //    Console.WriteLine("Exception: " + ex.Message);
            //} 
            #endregion

            #region Question1
            //What is the default value assigned to array elements in C#? 
            //    int, double, float 0
            //    bool false
            //    string, reference types  null 
            #endregion

            #region Problem2
            //int [ ] arr1 = {1, 2, 3};
            //int [ ] arr2 = {4, 5, 6};
            //Console.WriteLine("Before: ");
            //Console.WriteLine(arr1.GetHashCode());
            //Console.WriteLine(arr2.GetHashCode());
            //Console.WriteLine("After shallow copy: ");
            //arr2= arr1;
            //Console.WriteLine(arr1.GetHashCode());
            //Console.WriteLine(arr2.GetHashCode());

            //arr2[0] = 3;
            //Console.WriteLine(arr1[0]);

            //arr2 = (int[ ])arr1.Clone();
            //Console.WriteLine("After deep copy: ");
            //Console.WriteLine(arr1.GetHashCode());
            //Console.WriteLine(arr2.GetHashCode());
            //Console.WriteLine(arr1[2]);
            //Console.WriteLine(arr2[2]);

            //arr1[1] = 6;
            //Console.WriteLine(arr2[1]);

            #endregion

            #region Question2
            //What is the difference between Array.Clone() and Array.Copy() ?
            //    Array.Clone() creates a shallow copy of the array.
            //    Array.Copy() copies elements from one array to another, but you need to specify the destination array and index. 
            #endregion

            #region Problem3
            //int[,] grade = new int[3, 3];
            //Console.WriteLine(grade.Length);
            //for (int i = 0; i < 3; i++)
            //{
            //    Console.WriteLine($"enter grades for student {i + 1}: ");
            //    for (int j = 0; j < 3; j++)
            //    {
            //        Console.WriteLine($"subject {j + 1}: ");
            //        grade[i, j] = int.Parse(Console.ReadLine());
            //    }
            //}

            //Console.WriteLine("student grades..");
            //for (int i = 0; i < 3; i++)
            //{
            //    Console.WriteLine($"student {i + 1}:");
            //    for (int j = 0; j < 3; j++)
            //    {
            //        Console.WriteLine(grade[i, j]);
            //    }
            //    Console.WriteLine();
            //}

            #endregion

            #region Question3
            //What is the difference between GetLength() and Length for multidimensional arrays?
            //    array.Length returns the total number of elements in the array.
            //    array.GetLength(dimension) returns the number of elements in a specific dimension(e.g., rows or columns). 
            #endregion

            #region Problem4
            //int[] arr = { 1, 4, 3, 5 };
            //Console.WriteLine("Original: ");
            //for (int i = 0; i < arr.Length; i++)
            //{
            //    Console.WriteLine(arr[i]+ " ");
            //}

            //Array.Sort(arr);
            //Console.WriteLine("Sorted: ");
            //foreach (int i in arr)
            //{
            //    Console.WriteLine(i +" ");
            //}

            //Array.Reverse(arr);
            //Console.WriteLine("Reversed: ");
            //foreach(int i in arr)
            //{
            //    Console.WriteLine(i + " ");
            //}

            //int index = Array.IndexOf(arr, 5);
            //Console.WriteLine("Index of 5: " + index);

            //int[ ] copied = new int[4];
            //Array.Copy(arr , copied , arr.Length);
            //Console.WriteLine("Copied: ");
            //foreach (int i in copied)
            //{
            //    Console.WriteLine(i + " ");
            //}
            //Array.Clear(copied, 0, copied.Length);
            //Console.WriteLine("Cleared array:");
            //foreach (var num in copied) Console.Write(num + " ");
            //Console.WriteLine(); 
            #endregion

            #region Question4
            //What is the difference between Array.Copy() and Array.ConstrainedCopy() ?
            //   Array.Copy() is flexible and used in general copying.
            //   Array.ConstrainedCopy() ensures type safety and throws exceptions if the copy can't be completed. It's stricter and used in critical scenarios. 
            #endregion

            #region Problem5
            //int[] nums = { 1, 2, 3, 4, 5 };
            //Console.WriteLine("Using For: ");
            //for (int i = 0; i < 5 ; i++)
            //   Console.WriteLine(nums[i]);

            //Console.WriteLine("Using Foreach: ");
            //foreach(int i in nums)
            //   Console.WriteLine(i);

            //Console.WriteLine("Using While: ");
            //int j = nums.Length - 1;
            //while (j >= 0) {
            //    Console.WriteLine(nums[j]);
            //    j--;
            //} 
            #endregion

            #region Question5
            //Why is foreach preferred for read - only operations on arrays ?
            //   Because foreach is safer, cleaner, and prevents accidental modification of the array elements. 
            #endregion

            #region Problem6
            //int number;
            //do
            //{
            //    Console.Write("Enter a positive odd number: ");
            //    string input = Console.ReadLine();

            //    if (!int.TryParse(input, out number) || number <= 0 || number % 2 == 0)
            //    {
            //        Console.WriteLine("Invalid input. Try again.");
            //    }

            //} while (number <= 0 || number % 2 == 0);

            //Console.WriteLine("Valid number entered: " + number);
            //#endregion 
            #endregion

            #region Question6
            //Why is input validation important when working with user inputs?
            //   To prevent errors, crashes, and ensure the program behaves correctly and securely. 
            #endregion

            #region Problem7
            //int[,] arr = { { 1, 2, 3 }, { 4, 5, 6 }, { 7, 8, 9 } };

            //for (int i = 0; i < arr.GetLength(0); i++)
            //{
            //    for (int j = 0; j < arr.GetLength(1); j++)
            //    {
            //        Console.Write(arr[i,j] + "\t ");
            //    }
            //    Console.WriteLine();
            //} 
            #endregion

            #region Question7
            //How can you format the output of a 2D array for better readability?
            // Use tabs(\t) . 
            #endregion

            #region Problem8
            //Console.WriteLine("Enter month num(1:12)");
            //int month = int.Parse(Console.ReadLine());
            //Console.WriteLine("Using if else...");
            //if (month == 1)
            //    Console.WriteLine("January");
            //else if (month == 2)
            //    Console.WriteLine("February");
            //else if (month == 3)
            //    Console.WriteLine("March");
            //else if (month == 4)
            //    Console.WriteLine("April");
            //else if (month == 5)
            //    Console.WriteLine("May");
            //else if (month == 6)
            //    Console.WriteLine("June");
            //else if (month == 7)
            //    Console.WriteLine("July");
            //else if (month == 8)
            //    Console.WriteLine("August");
            //else if (month == 9)
            //    Console.WriteLine("September");
            //else if (month == 10)
            //    Console.WriteLine("October");
            //else if (month == 11)
            //    Console.WriteLine("November");
            //else if (month == 12)
            //    Console.WriteLine("December");
            //else 
            //    Console.WriteLine("Invalid month");


            //Console.WriteLine("Using switch...");
            //switch (month)
            //{
            //    case 1: Console.WriteLine("January"); break;
            //    case 2: Console.WriteLine("February"); break;
            //    case 3: Console.WriteLine("March"); break;
            //    case 4: Console.WriteLine("April"); break;
            //    case 5: Console.WriteLine("May"); break;
            //    case 6: Console.WriteLine("June"); break;
            //    case 7: Console.WriteLine("July"); break;
            //    case 8: Console.WriteLine("August"); break;
            //    case 9: Console.WriteLine("September"); break;
            //    case 10: Console.WriteLine("October"); break;
            //    case 11: Console.WriteLine("November"); break;
            //    case 12: Console.WriteLine("December"); break;
            //    default: Console.WriteLine("Invalid month"); break;
            //} 
            #endregion

            #region Question8
            //When should you prefer a switch statement over if-else?
            //   When comparing a variable against multiple constant values. switch is more readable and efficient in such cases. 
            #endregion

            #region Problem9
            //int[] arr = { 3, 2, 1, 3 };
            //Console.WriteLine("Original");
            //foreach (int i in arr)
            //{
            //    Console.WriteLine(i);
            //}

            //Array.Sort(arr);
            //Console.WriteLine("Sorted");
            //foreach(int i in arr)
            //{
            //    Console.WriteLine(i);
            //}

            //int firstindex = Array.IndexOf(arr, 3);
            //Console.WriteLine("Index of 3: " + firstindex);

            //int lastindex = Array.LastIndexOf(arr, 3);
            //Console.WriteLine("LastIndex of 3: "+lastindex); 
            #endregion

            #region Question9
            //What is the time complexity of Array.Sort() ?
            //    It uses QuickSort or Introspective Sort internally.
            //    Average time complexity: O(n log n). 
            #endregion

            #region Problem10
            //int[] arr = { 1, 2, 3, 4, 5 };
            //int sum = 0;
            //Console.WriteLine("Using for: ");
            //for (int i = 0; i < arr.Length; i++)
            //{
            //    sum += arr[i];
            //}
            //Console.WriteLine(sum);

            //int sum1 = 0;
            //Console.WriteLine("Using foreach: ");
            //foreach(int i in arr)
            //{
            //    sum1+= i;
            //}
            //Console.WriteLine(sum1); 
            #endregion

            #region Question10
            //Which loop is more efficient for calculating the sum of an array, and why ?
            //    Both are nearly the same in performance. for gives more control; foreach is cleaner and preferred for read - only operations. 
            #endregion


            
            #region Part02
            //Console.Write("Enter num(1:7): ");
            //int input = int.Parse(Console.ReadLine());
            //if (input >= 1 && input <= 7)
            //{
            //    DayOfWeek day = (DayOfWeek)input;
            //    Console.WriteLine("Day "+ day);
            //}
            //else
            //{
            //    Console.WriteLine("Invalid day number.");
            //} 
            #endregion





















        }
    }
}
