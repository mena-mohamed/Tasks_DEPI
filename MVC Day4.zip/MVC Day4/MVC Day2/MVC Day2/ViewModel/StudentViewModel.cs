﻿using MVC_Day2.Models;

namespace MVC_Day2.ViewModel
{
    public class StudentViewModel
    {
        public Student Student { get; set; }
        public List<Department> Departments { get; set; }
    }
}
