﻿using MVC_Day2.Data;
using Microsoft.EntityFrameworkCore;

namespace MVC_Day2.Models
{
    public class StudentBL
    {
        MvcDbContext context = new MvcDbContext();

        public List<Student> GetAll()
        {
            return context.Students.ToList();
        }

        public Student? GetById(int id)
        {
            return context.Students.FirstOrDefault(s => s.Id == id);
        }

        public void Add(Student student) 
        {
            context.Students.Add(student);
            context.SaveChanges();
        }

        public void Update(Student student)
        {
            context.Students.Update(student);
            context.SaveChanges();
        }

        public void Delete(int id)
        {
            var std = GetById(id);
            if (std != null)
            {
                context.Students.Remove(std);
                context.SaveChanges();
            }
        }
    }
}
