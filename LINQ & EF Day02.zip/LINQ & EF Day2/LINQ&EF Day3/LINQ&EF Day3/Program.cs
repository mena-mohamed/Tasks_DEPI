﻿using System;
using System.ComponentModel;
using System.Linq;
using static LINQ_EF_Day3.ListGenerators;
namespace LINQ_EF_Day3
{

    internal class Program
    {
        static void Main(string[] args)
        {
            #region LINQ - Restriction Operators
            //1
            //var res1 = ProductList.Where((p) => p.UnitsInStock == 0);
            //foreach (var unit in res1)
            //{
            //    Console.WriteLine(unit);
            //}

            //2
            //var res2 = ProductList.Where((p) => p.UnitsInStock > 0 && p.UnitPrice > 3.00M);
            //foreach (var item in res2)
            //{
            //    Console.WriteLine(item);
            //}

            //3
            //string[] Arr = { "zero", "one", "two", "three", "four", "five", "six", "seven", "eight",
            //                "nine" };
            //var res3 = Arr.Where((name,index) => name.Length <  index);
            //foreach (var item in res3)
            //{
            //    Console.WriteLine(item);
            //} 
            #endregion

            #region LINQ - Element Operators
            //var first = ProductList.FirstOrDefault(p => p.UnitsInStock == 0);
            //Console.WriteLine(first);

            //var first1 = ProductList.FirstOrDefault(p => p.UnitPrice > 1000);
            //if (first1 != null) 
            //    Console.WriteLine(first1);
            //Console.WriteLine("Not found");

            //int[] Arr = { 5, 4, 1, 3, 9, 8, 6, 7, 2, 0 };
            //var second = Arr.Where( n => n > 5).Skip(1).FirstOrDefault();
            //Console.WriteLine(second); 
            #endregion

            //1
            //int[] Arr = { 5, 4, 1, 3, 9, 8, 6, 7, 2, 0 };
            //var con = Arr.Where((p) => p%2!=0);
            //foreach (int i in con)
            //{
            //    Console.WriteLine(i);
            //}

            //2
            //var cust = CustomerList.Select(c => new
            //{
            //    c.Name,
            //    OrderCount = c.Orders.Count(o => o != null)
            //});
            //foreach (var c in cust)
            //{
            //    Console.WriteLine($"{c.Name} has {c.OrderCount} orders.");
            //}

            //3
            //var catog = ProductList.GroupBy(p => p.Category)
            //                       .Select(p => new
            //                       {
            //                           Category = p.Key,
            //                           Count = p.Count()
            //                       });
            //foreach (var item in catog) 
            //    Console.WriteLine($"{item.Category}: {item.Count} product");

            //4
            //int[] Arr = { 5, 4, 1, 3, 9, 8, 6, 7, 2, 0 };
            //int total = Arr.Sum();
            //Console.WriteLine(total);

            //5

        }
    }
}
