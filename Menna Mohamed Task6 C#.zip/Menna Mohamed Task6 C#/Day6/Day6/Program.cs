﻿using Microsoft.VisualBasic;
using System;
using System.Collections.ObjectModel;
using System.Drawing;



namespace Day6
{
    internal class Program
    {
     
        static void Main(string[] args)
        {
            #region Problem1
            //point p1= new point(3,4);
            //Console.WriteLine(p1); 
            #endregion

            #region Question1
            //Why can't a struct inherit from another struct or class in C#?
            // In C#, structs are value types and are designed for lightweight data structures without inheritance overhead.    
            //They implicitly inherit from System.ValueType and cannot inherit from another struct or class. This ensures structs remain small, 
            //fast, and immutable-like.However, they can implement interfaces. 
            #endregion

            #region Problem2
            //TypeA tp=new TypeA();
            //tp.PrintValues();
            //Console.WriteLine($"G (internal): {tp.g}");
            //Console.WriteLine($"H (public): {tp.h}");
            //// can’t access f because private 
            #endregion

            #region Question2
            //How do access modifiers impact the scope and visibility of a class member?
            //   Access modifiers define where a member can be accessed:
            //   private → Only inside the same class.
            //   internal → Anywhere in the same assembly.
            //   public → Anywhere in the program.
            //   protected → In the same class or derived classes.
            //   protected internal → Derived classes or same assembly.
            //   private protected → Derived classes in the same assembly.   
            #endregion

            #region Problem3
            //Employee emp = new Employee(1, "Menna", 30000);
            //Console.WriteLine(emp);

            //emp.SetName("Yazed");
            //emp.EmpSal=10000;

            //Console.WriteLine($"After Update: {emp.GetName( )}, Salary: {emp.EmpSal}"); 
            #endregion

            #region Question3
            //Why is encapsulation critical in software design?
            //    Encapsulation hides the internal state and requires all interactions to occur through controlled methods or properties.
            //   This improves security, data integrity, maintainability, and allows changing implementation without affecting other code. 
            #endregion

            #region Problem4
            //point p2 = new point(2,8);
            //point p3 = new point(-3,0);
            //point p4 = new point(10,10);

            //Console.WriteLine(p2);
            //Console.WriteLine(p3);
            //Console.WriteLine(p4); 
            #endregion

            #region Question4
            //What are constructors in structs?
            // Constructors in structs initialize fields when creating an instance.Structs:
            // Always have a default constructor(provided by the compiler).
            // Can have parameterized constructors but must initialize all fields. 
            #endregion

            #region Problem5
            //point p1 = new point(1,11);
            //ChangePoint(p1);
            //Console.WriteLine($"After ChangePoint: X={p1.X}, Y={p1.Y}");

            //Employee emp1 = new Employee(1, "Farha", 6000);
            //ChangeEmployee(emp1);
            //Console.WriteLine($"After change: Name={emp1.GetName()}, Salary={emp1.EmpSal}");

            //static void ChangePoint(point point)
            //{
            //    point.X = 20;
            //    point.Y = 40;
            //}

            //static void ChangeEmployee(Employee emp)
            //{
            //    emp.SetName("Mo");
            //    emp.EmpSal = 20000;
            //} 
            #endregion

            #region Problem6
            //point p1 = new point(16, 20);
            //point p2 = p1; 
            //p2.X = 99;

            //Console.WriteLine($"p1 (struct): {p1}");
            //Console.WriteLine($"p2 (struct): {p2}");


            //Employee e1 = new Employee(1, "Ali", 5000);
            //Employee e2 = e1;
            //e2.SetName("Ahmed");

            //Console.WriteLine($"e1 (class): Name = {e1.GetName()}, Salary = {e1.EmpSal}");
            //Console.WriteLine($"e2 (class): Name = {e2.GetName()}, Salary = {e2.EmpSal}"); 
            #endregion

            #region Question6
            //How does memory allocation differ for structs and classes in C#?
            // Structs(value types) → Stored on the stack(or inline in containing object), copied on assignment, no garbage collection needed.
            // Classes(reference types) → Stored on the heap, only references are copied, require garbage collection. 
            #endregion


        }
    }

}
    

