﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day6
{
    internal class Employee
    {
        private int EmpId;
        private string Name;
        private double Salary;

        public Employee(int id,string name,double sal)
        {
            EmpId = id;
            Name = name;
            Salary = sal;
        }
        public Employee(string name,double sal) { 
            Name = name;
            Salary = sal;
         }

        public string  GetName() { return Name; }
        public void SetName(string name) { Name = name; }

        public int ID
        {
            get { return EmpId; }
            set { EmpId = value; }
        }
        public double EmpSal
        {
            get { return Salary; }
            set { Salary = value; }
        }
        public override string ToString()
        {
            return $"ID: {EmpId}, Name: {Name}, Salary: {Salary}";
        }


    }
}
