﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day6
{
    public class TypeA
    {
        private int f =5;
        internal int g = 20;
        public int h = 35;

        public void PrintValues()
        {
            Console.WriteLine($"Inside TypeA F: {f}, G: {g}, H: {h}");
        }
    }
}
