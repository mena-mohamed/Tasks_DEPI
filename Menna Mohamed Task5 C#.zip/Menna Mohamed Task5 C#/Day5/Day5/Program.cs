﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Linq.Expressions;
using System.Reflection.Metadata;
using System.Reflection.PortableExecutable;
using System.Resources;
using System.Security.Cryptography;
using System.Security.Principal;
using System.Text;
using System.Xml.Linq;

namespace Day5
{
    internal class Program
    {
        //problem 2
        static void TestDefensiveCode()
        {
            int x, y;
            while (true)
            {
                Console.WriteLine("Enter pos num x: ");
                if (int.TryParse(Console.ReadLine(), out x) && x > 0)
                {
                    break;
                }
                Console.WriteLine("must be greater than zero");
            }
            while (true)
            {
                Console.WriteLine("Enter pos num  y > 1: ");
                if (int.TryParse(Console.ReadLine(), out y) && y > 1)
                {
                    break;
                }
                Console.WriteLine("must be greater than 1");
            }

            Console.WriteLine($"X = {x} , Y = {y}");


        }
        //problem 9
        static void SumAndMultiply(int a, int b, out int sum, out int product)
        {
            sum = a + b;
            product = a * b;
        }

        // problem 10
        static void PrintMessage(string message, int times)
        {
            for (int i = 0; i < times; i++)
                Console.WriteLine(message);
        }

        //problem 13
        static int PrintSum(params int[] numbers)
        {
            int sum = 0;
            foreach (int num in numbers)
            {
                sum += num;
            }
            return sum;
        }
        static void Main(string[] args)
        {
            //Part 01

            #region Problem1
            //try
            //{
            //    Console.WriteLine("Enter first integer: ");
            //    int num1 = int.Parse(Console.ReadLine());
            //    Console.WriteLine("Enter second integer: ");
            //    int num2 = int.Parse(Console.ReadLine());
            //    int result = num1 / num2;
            //    Console.WriteLine($"Result: {result}");
            //}
            //catch (DivideByZeroException)
            //{
            //    Console.WriteLine("Error:divided by zero!");
            //}
            //finally
            //{
            //    Console.WriteLine("Operation complete");

            //} 
            #endregion

            #region Question1
            //What is the purpose of the finally block?
            //    The finally block is executed regardless of whether an exception occurs or not.It is typically used for cleanup operations 
            //    (like closing files, releasing resources) or to ensure that certain code always runs. 
            #endregion

            #region Problem2
            //TestDefensiveCode(); 
            #endregion

            #region Question2
            //How does int.TryParse() improve program robustness compared to int.Parse() ?
            //    int.TryParse() does not throw an exception if the input is invalid.Instead, it returns false, allowing the program to handle the error gracefully and avoid crashes. 
            #endregion

            #region Problem3
            //int? num = null;
            //int x = num ?? 3;
            //Console.WriteLine($"X = {x}");
            //if (num.HasValue)
            //    Console.WriteLine($"True, Value = {num}");
            //else
            //    Console.WriteLine("false"); 
            #endregion

            #region Question3
            //What exception occurs when trying to access Value on a null Nullable<T>?
            //   InvalidOperationException occurs if you try to access .Value when the nullable has no value(null). 
            #endregion

            #region Problem4
            //int[] arr = new int[5]; 
            //try
            //{
            //    arr[5] = 9;
            //}
            //catch (IndexOutOfRangeException)
            //{
            //    Console.WriteLine($"error: out of range");
            //} 
            #endregion

            #region Question4
            //Why is it necessary to check array bounds before accessing elements?
            //  To prevent IndexOutOfRangeException. 
            #endregion

            #region Problem5
            //int[,] arr = new int[3, 3];

            //for(int i = 0; i < arr.GetLength(0); i++)
            //{
            //    for(int j = 0; j < arr.GetLength(1); j++)
            //    {
            //        Console.WriteLine("Enter values for[i,j]: ");
            //        arr[i,j] =int.Parse(Console.ReadLine()); 
            //    }
            //}
            //for(int i=0; i < arr.GetLength(0); i++)
            //{
            //    int rowsum = 0;
            //    for(int j=0; j < arr.GetLength(1); j++) 
            //        rowsum += arr[i,j];
            //    Console.WriteLine($"Sum of Rows: {rowsum}");
            //}

            //for (int j = 0; j < arr.GetLength(1); j++)
            //{
            //    int columnsum = 0;
            //    for (int i = 0; i < arr.GetLength(0); i++)
            //        columnsum += arr[i,j];
            //    Console.WriteLine($"Sum of coloum: {columnsum}");
            //} 
            #endregion

            #region Question5
            //How is the GetLength(dimension)method used in multi - dimensional arrays?
            //  GetLength(0) returns the number of rows, and GetLength(1) returns the number of columns in a 2D array. 
            #endregion

            #region Problem6
            //int[][] arr = new int[3][];
            //arr[0] = new int[2];
            //arr[1] = new int[4];
            //arr[2] = new int[3];

            //for (int i = 0; i < arr.Length; i++)
            //{
            //    for (int j = 0; j < arr[i].Length; j++)
            //    {
            //        Console.WriteLine($"Enter value for row{i} , column{j}: ");
            //        arr[i][j] = int.Parse(Console.ReadLine());
            //    }
            //}
            //for (int i = 0; i < arr.Length; i++)
            //{
            //    for (int j = 0; j < arr[i].Length; j++)
            //        Console.Write(arr[i][j] + " ");
            //    Console.WriteLine();
            //} 
            #endregion

            #region Question6
            //How does the memory allocation differ between jagged arrays and rectangular arrays?
            // Jagged arrays are arrays of arrays. Each row is stored separately and can have a different length, so memory is allocated individually for each row.
            // Rectangular arrays have a single memory block for all elements, with fixed dimensions for all rows and columns. 
            #endregion

            #region Problem7
            //Console.WriteLine("Enter your name ");
            //string? name = Console.ReadLine();
            //Console.WriteLine("Menna, " + name!); 
            #endregion

            #region Question7
            //What is the purpose of nullable reference types in C#?
            //  They help identify potential null reference issues at compile time by distinguishing between nullable(string ?) and non-nullable(string) reference types,
            //  reducing the chance of NullReferenceException at runtime. 
            #endregion

            #region Problem8
            ////boxing
            //int x = 30;
            //object boxed = x;

            ////unboxing
            //int unboxed = (int)boxed;
            //Console.WriteLine($"Unboxed value: {unboxed}");

            //object box = 4.9;
            //try
            //{
            //    int z = (int)box;
            //}
            //catch (InvalidCastException ex)
            //{
            //    Console.WriteLine("Error, " + ex.Message );
            //} 
            #endregion

            #region Question8
            //What is the performance impact of boxing and unboxing in C#?
            // Boxing allocates memory on the heap and unboxing requires type checking. 
            #endregion

            #region Problem9
            //SumAndMultiply(3, 4, out int sum, out int product);
            //Console.WriteLine($"Sum:{sum} , Product:{product}"); 
            #endregion

            #region Question9
            //Why must out parameters be initialized inside the method?
            //  Because the caller expects them to have a value when the method returns, so the compiler enforces that they are definitely assigned inside the method before use. 
            #endregion

            #region Problem10
            //PrintMessage("Menna", 4); 
            #endregion

            #region Question10
            //Why must optional parameters always appear at the end of a method's parameter list?
            //  To avoid ambiguity in method calls and ensure the compiler can match provided arguments to the correct parameters. 
            #endregion

            #region Problem11
            //int[]? arr = null;
            //Console.WriteLine("Array length: "+( arr?.Length??0)); 
            #endregion

            #region Question11
            //How does the null propagation operator prevent NullReferenceException?
            //  It stops the evaluation if the object is null and returns null instead, avoiding a direct access that would cause a NullReferenceException. 
            #endregion

            #region Problem12
            //Console.WriteLine("Enter a day of week(small char): ");
            //string day = Console.ReadLine();

            //int Daynum = day switch
            //{
            //    "saturday" => 1,
            //    "sunday" => 2,
            //    "monday" => 3,
            //    "tuesday" => 4,
            //    "wednesday" => 5,
            //    "thursday" => 6,
            //    "friday" => 7,
            //    _ => 0
            //};

            //if (Daynum == 0) 
            //    Console.WriteLine("invalid day entered.");
            //else
            //        Console.WriteLine($"The number for {day} is {Daynum}."); 
            #endregion

            #region Question12
            //When is a switch expression preferred over a traditional if statement ?
            //   When matching a single value against multiple discrete options, switch expressions are more concise, readable, 
            //   and maintainable than multiple if-else statements 
            #endregion

            #region Problem13
            //// individual values
            //int result1 = PrintSum(1, 2, 3);
            //Console.WriteLine($"Sum of individual values: {result1}");

            //// array values
            //int[] arr = { 10, 20, 30 };
            //int result2=PrintSum(arr);
            //Console.WriteLine($"Sum of array values: {result2}"); 
            #endregion

            #region Question13
            //Question: What are the limitations of the params keyword in method definitions?
            //  1.The params parameter must be the last parameter in the method definition.
            //  2.There can be only one params parameter in a method.
            //  3.All arguments passed to a params parameter must be of the same type as the parameter’s array type.
            //  4.If you pass an array, it will be used directly; if you pass individual values, they are converted into an array automatically. 
            #endregion


            //Part 02

            #region Problem1
            //Console.Write("Enter pos num:");
            //int num=int.Parse(Console.ReadLine());
            //for (int i = 1; i <= num; i++)
            //{
            //    Console.Write(i + " ");
            //} 
            #endregion

            #region Problem2
            //Console.Write("Enter num,plz: ");
            //int num = int.Parse(Console.ReadLine());
            //for (int i = 1; i <= 12; i++)
            //{
            //    Console.Write(i * num);
            //    if(i<12) Console.Write(",");       
            //} 
            #endregion

            #region Problem3
            //Console.Write("Enter number: ");
            //int num=int.Parse(Console.ReadLine());
            //for(int i = 1; i <= num; i++)
            //{
            //    if(i%2==0)
            //        Console.Write(i + ", ");
            //}     
            #endregion

            #region Problem4
            //Console.WriteLine("Enter base num: ");
            //int basenum=int.Parse(Console.ReadLine());
            //Console.WriteLine("Enter exponent: ");
            //int exponent=int.Parse(Console.ReadLine());

            //int result = 1;
            //for(int i = 1;i <= exponent;i++)
            //    result*=basenum;
            //Console.WriteLine($"{basenum}^{exponent} = {result}"); 
            #endregion

            #region Problem5
            //Console.WriteLine("Enter a string: ");
            //string input=Console.ReadLine();

            //char[] chars = input.ToCharArray();
            //Array.Reverse(chars);
            //string reversed = new string(chars);
            //Console.WriteLine("Reversed string: " + reversed); 
            #endregion

            #region Problem6
            //Console.WriteLine("Enter number: ");
            //int num=int.Parse(Console.ReadLine());
            //int reversed = 0;
            //while (num != 0)
            //{
            //    reversed = reversed * 10 + num % 10;
            //    num = num / 10;
            //}
            //Console.WriteLine("Reversed: " + reversed); 
            #endregion

            #region Problem7
            //Console.WriteLine("Enter array size: ");
            //int n=int.Parse(Console.ReadLine());    
            //int[] arr=new int[n];
            //Console.WriteLine("Enter array elements: ");
            //for (int i = 0;i < n; i++)
            //{
            //    arr[i] = int.Parse(Console.ReadLine());
            //}
            //int maxdist = -1;
            //for (int i = 0; i<n ; i++)
            //{
            //    for(int j = i+1; j < n ; j++)
            //    {
            //        if( arr[i] == arr[j])
            //        {
            //            int distance = j - i - 1;
            //            if( distance > maxdist )
            //                maxdist = distance;
            //        }
            //    }
            //}
            //Console.WriteLine("Longest distance: " + maxdist); 
            #endregion

            #region Problem8
            //Console.WriteLine("Enter a statement: ");
            //string statement=Console.ReadLine();

            //string[] words = statement.Split(' ', StringSplitOptions.RemoveEmptyEntries);
            //Array.Reverse(words);
            //for (int i = 0; i < words.Length; i++)
            //{
            //    Console.Write(words[i] + " ");
            //} 
            #endregion












        }
    }
  } 
