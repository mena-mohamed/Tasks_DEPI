﻿using System;

namespace Project
{
    internal class ChooseOneQuestion : Question
    {
        public int correctChoice;
      

        public ChooseOneQuestion(string header, string body, int marks, int correct)
            : base(header, body, marks)
        {
            correctChoice = correct;
        }

        public override void DisplayQuestion()
        {
            Console.WriteLine($"{Header}: {Body} ({Marks} marks) - Choose One");
            for (int i = 0; i < Answers.Count(); i++)
            {
                Console.WriteLine($"{i + 1}. {Answers.Get(i).AnswerText}");
            }
        }

        public override bool CheckAnswer(string studentAnswer)
        {
            int choice = int.Parse(studentAnswer);
            return choice == correctChoice;
           
        }
    }
}

