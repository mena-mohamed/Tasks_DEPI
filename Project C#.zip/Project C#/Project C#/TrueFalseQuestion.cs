﻿using System;

namespace Project
{
    internal class TrueFalseQuestion : Question
    {
        public bool correctAnswer;
        string examType;


        public TrueFalseQuestion(string header, string body, int marks, bool correct)
            : base(header, body, marks)
        {
            correctAnswer = correct;
        }

        public override void DisplayQuestion()
        {
            Console.WriteLine($"{Header}: {Body} ({Marks} marks) - (t/f)");
        }

        public override bool CheckAnswer(string studentAnswer)
        {
            return (studentAnswer.ToLower() == "t" && correctAnswer )
                          || (studentAnswer.ToLower() == "f" && !correctAnswer);

          
        }
    }
}



