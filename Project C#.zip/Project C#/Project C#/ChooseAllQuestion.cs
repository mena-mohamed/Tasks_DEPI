﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Project
{
    internal class ChooseAllQuestion : Question
    {
        private List<int> correctChoices;

        public ChooseAllQuestion(string header, string body, int marks, List<int> correct)
            : base(header, body, marks)
        {
            correctChoices = correct;
        }

        public ChooseAllQuestion()
            : this("Choose All Question", "No Body", 1, new List<int> { 1 }) { }

        public override void DisplayQuestion()
        {
            Console.WriteLine($"{Header}: {Body} ({Marks} marks) - Choose All Correct Answers");
            for (int i = 0; i < Answers.Count(); i++)
            {
                Console.WriteLine($"{i + 1}. {Answers.Get(i).AnswerText}");
            }
        }

        public override bool CheckAnswer(string studentAnswer)
        {
            var parts = studentAnswer.Split(',', StringSplitOptions.RemoveEmptyEntries);
            List<int> chosen = new List<int>();

            foreach (var p in parts)
            {
                if (int.TryParse(p.Trim(), out int choice))
                    chosen.Add(choice);
            }

            return chosen.Count == correctChoices.Count && !chosen.Except(correctChoices).Any();
        }
    }
}