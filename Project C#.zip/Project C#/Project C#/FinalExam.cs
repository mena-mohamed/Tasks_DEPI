﻿using Project_C_;
using System;

namespace Project
{
    internal class FinalExam : Exam
    {
        public FinalExam(string subject, string code, int time)
            : base(subject, code, time) { }

        public FinalExam() : this("No Subject", "000", 0) { }

        public void ShowExam(Student student)
        {
            Console.WriteLine($"\n=== Student: {student.Name} ===");

            for (int i = 0; i < Questions.Count(); i++)
            {
                Question q = Questions.Get(i);
                q.DisplayQuestion();

                Console.Write("Your Answer: ");
                string answer = Console.ReadLine();

                if (q.CheckAnswer(answer))
                {
                    Console.WriteLine("Correct!");
                    student.Score += q.Marks;
                   
                }
               

                    //Console.WriteLine("-----------------------------");
            }

            Console.WriteLine($"\n=== Exam Finished! ===");
            Console.WriteLine("Your final score: " + student.Score);
        }
    }
}
