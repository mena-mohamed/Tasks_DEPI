﻿using Project_C_;
using System;

namespace Project
{
    internal class PracticeExam : Exam
    {
        public PracticeExam(string subject, string code, int time)
            : base(subject, code, time) { }

        public PracticeExam() : this("No Subject", "000", 0) { }

        public void ShowExam(Student student)
        {
            Console.WriteLine($"\n=== Student: {student.Name} ===");

            for (int i = 0; i < Questions.Count(); i++)
            {
                Question q = Questions.Get(i);
                q.DisplayQuestion();

                Console.Write("Your Answer: ");
                string answer = Console.ReadLine();

                if (q.CheckAnswer(answer))
                {
                    Console.WriteLine("Correct!");
                    student.Score += q.Marks;
                }
                //else
                //{
                //    Console.WriteLine("Wrong!");
                //}

                
                //Console.WriteLine("Correct Answer(s):");
                //for (int j = 0; j < q.Answers.Count(); j++)
                //{
                //    Console.WriteLine($"{q.Answers.Get(j).AnswerId}. {q.Answers.Get(j).AnswerText}");
                //}

                Console.WriteLine("-----------------------------");
            }

            Console.WriteLine($"\n=== Exam Finished! ===");
            Console.WriteLine("Your final score: " + student.Score);
        }
    }
}

