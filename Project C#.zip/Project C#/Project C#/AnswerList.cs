﻿using Project_C_;
using System;
using System.Collections.Generic;

namespace Project
{
    internal class AnswerList
    {
        private List<Answer> answers = new List<Answer>();

        public void Add(Answer a)
        {
            answers.Add(a);
        }

        public Answer Get(int index)
        {
            return answers[index];
        }

        public int Count()
        {
            return answers.Count;
        }
    }
}