﻿using System;

namespace Project
{
    internal class Exam
    {
        public enum ExamMode { Queued, Starting, Finished }

        public string Subject { get; set; }
        public string SubjectCode { get; set; }
        public int Time { get; set; }
        public QuestionList Questions { get; set; }
        public ExamMode Mode { get; set; }

        public Exam(string subject, string code, int time)
        {
            Subject = subject;
            SubjectCode = code;
            Time = time;
            Questions = new QuestionList();
            Mode = ExamMode.Queued;
        }

        public Exam() : this("No Subject", "000", 0) { }

        public void StartExam(string studentName)
        {
            Mode = ExamMode.Starting;
            Console.WriteLine($"Notification: Exam on {Subject} is starting!, {studentName}");
        }

        public void FinishExam()
        {
            Mode = ExamMode.Finished;
            Console.WriteLine($"Exam on {Subject} has finished.");
        }
    }
}
