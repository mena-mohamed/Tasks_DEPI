﻿using Project_C_;
using System;

namespace Project
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("=========== Welcome to the Examination Platform =========\n");

            Console.Write("Enter your name: ");
            string name = Console.ReadLine();

            Console.Write("Enter your ID: ");
            string id = Console.ReadLine();

            Student student = new Student(name, id);

            Console.WriteLine("\nSelect Exam Type: 1. Practice Exam  2. Final Exam");
            string examChoice = Console.ReadLine();

            string examType = examChoice == "1" ? "Practical" : "Final";

            Exam exam = new Exam("C# Programming", "CS101", 30);
            exam.Questions.Add(new TrueFalseQuestion("Q1", "Class cannot contain methods, only properties?", 5, false));

            var q2 = new ChooseOneQuestion("Q2", "Select correct keyword!", 5, 1);
            q2.Answers.Add(new Answer(1, "class"));
            q2.Answers.Add(new Answer(2, "interface"));
            q2.Answers.Add(new Answer(3, "package"));
            exam.Questions.Add(q2);

            Console.WriteLine($"\nExam created: Subject: {exam.Subject}, SubjectCode: {exam.SubjectCode},");
            Console.WriteLine($"Time: {exam.Time} mins, Questions: {exam.Questions.Count()},");
            Console.WriteLine($"Mode: {exam.Mode}, Type: {examType}");

            exam.StartExam(student.Name);

            Console.WriteLine($"\n=== Student: {student.Name} ===");

            for (int i = 0; i < exam.Questions.Count(); i++)
            {
                Question q = exam.Questions.Get(i);
                q.DisplayQuestion();

                Console.Write("Your Answer: ");
                string answer = Console.ReadLine();

                bool correct = q.CheckAnswer(answer);

               
                if (examType == "Practical")
                {
                    if (correct)
                    {
                        Console.WriteLine("Correct!");
                    }
                    else
                    {
                        if (q is ChooseOneQuestion choQ)
                            Console.WriteLine("Correct Answer: " + choQ.Answers.Get(choQ.correctChoice - 1).AnswerText);
                        else if (q is TrueFalseQuestion tfQ)
                            Console.WriteLine("Correct Answer: " + (tfQ.correctAnswer ? "True" : "False"));
                    }

                  
                    Console.WriteLine("--------------------------------------------------");
                }

                if (correct)
                {
                    student.Score += q.Marks;
                }
            }

            exam.FinishExam();

            
            Console.WriteLine("\n=========== Exam Report ===========");
            Console.WriteLine($"Name     : {student.Name}");
            Console.WriteLine($"ID       : {student.Id}");
            Console.WriteLine($"Score    : {student.Score}");
            Console.WriteLine($"Percent  : {(student.Score * 100) / 10}%");
            Console.WriteLine($"Exam Mode: {exam.Mode}");
            Console.WriteLine($"Exam Type: {examType}");
            Console.WriteLine("===================================");

            Console.WriteLine("\n========= Thank you for taking the exam! =========");
        }
    }
}











