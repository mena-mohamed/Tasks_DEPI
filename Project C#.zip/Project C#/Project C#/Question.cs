﻿using System;
using System.Collections.Generic;

namespace Project
{
    internal abstract class Question
    {
        private static int counter = 1;

        public int QuestionId { get; private set; }
        public string Header { get; set; }
        public string Body { get; set; }
        public int Marks { get; set; }
        public AnswerList Answers { get; set; }

        public Question(string header, string body, int marks)
        {
            QuestionId = counter++;
            Header = header;
            Body = body;
            Marks = marks;
            Answers = new AnswerList();
        }

        public Question() : this("No Header", "No Body", 0) { }

        public abstract void DisplayQuestion();
        public abstract bool CheckAnswer(string studentAnswer);
    }
}
