﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_C_
{
    internal class Student
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public int Score { get; set; } = 0;

        public Student(string name, string id, int score)
        {
            Id = id;
            Name = name;
            Score = score;
        }

        public Student(string id, string name) : this(id, name, 0) { }
        public Student(string name) : this("00", "No Name", 0)
        {
            Name = name;
        }

        public void ReceiveNotification(string message)
        {
            Console.WriteLine($"Notification: {message}, {Name}");
        }
    }
}
