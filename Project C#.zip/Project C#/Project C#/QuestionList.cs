﻿using System;
using System.Collections.Generic;

namespace Project
{
    internal class QuestionList
    {
        private List<Question> questions;

        public QuestionList(List<Question> qs)
        {
            questions = qs;
        }

        public QuestionList() : this(new List<Question>()) { }

        public void Add(Question q)
        {
            questions.Add(q);
        }

        public Question Get(int index)
        {
            return questions[index];
        }

        public int Count()
        {
            return questions.Count;
        }
    }
}

