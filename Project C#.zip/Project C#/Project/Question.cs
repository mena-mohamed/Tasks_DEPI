﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project
{
    public abstract class Question
    {
        private static int nextID = 1;
        public int QuestionId { get; set; }
        public string Header { get; set; }
        public string Body { get; set; }
        public int Marks { get; set; }
        public AnswerList Answers { get; set; }

        public Question(string header, string body, int marks)
        {
            QuestionId = nextID++;
            Header = header;
            Body = body;
            Marks = marks;
            Answers = new AnswerList();
        }

        public Question(string header, string body) : this(header, body, 0) { }
        public Question() : this("No Header", "No Body", 0) { }

        public abstract void DisplayQuestion();
        public abstract bool CheckAnswer(string studentAnswer);

        public override string ToString()
        {
            return $"[QID: {QuestionId} {Header}: {Body} ({Marks} Marks)]";
        }

        public override bool Equals(object obj)
        {
            if (obj is Question q)
                return QuestionId.Equals(q.QuestionId);
            return false;
        }

        public override int GetHashCode()
        {
            return QuestionId.GetHashCode();
        }
    }

}
