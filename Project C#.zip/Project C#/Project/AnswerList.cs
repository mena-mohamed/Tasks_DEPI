﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project
{
    public class AnswerList
    {
        private List<Answer> answers = new List<Answer>();

        public void Add(Answer a) => answers.Add(a);
        public Answer this[int index] => answers[index];
        public int Count => answers.Count;

        public override string ToString()
        {
            return string.Join(", ", answers);
        }
    }

}
