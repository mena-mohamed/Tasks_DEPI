﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project
{
    internal class FinalExam : Exam
    {
        public FinalExam(Subject subject, int time, string questionLogFile) : base(subject, time, questionLogFile) { }
        public FinalExam(Subject subject, int time) : this(subject, time, "FinalQuestions.txt") { }
        public FinalExam() : this(new Subject(), 45, "FinalQuestions.txt") { }

        public override void ShowExam(List<Student> students)
        {
            int maxScore = 0;
            for (int i = 0; i < Questions.Count; i++)
                maxScore += Questions[i].Marks;

            foreach (var student in students)
            {
                Console.WriteLine($"\n=== Student: {student.Name} ===");
                student.Score = 0;

                for (int i = 0; i < Questions.Count; i++)
                {
                    var q = Questions[i];
                    q.DisplayQuestion();
                    Console.Write("Your Answer: ");
                    string ans = Console.ReadLine();

                    bool correct = q.CheckAnswer(ans);
                    if (correct) student.Score += q.Marks;

                    Console.WriteLine(correct ? "Correct!" : "Wrong!");
                    Console.WriteLine("-------------------");
                }

                Console.WriteLine($"\n=== Exam Finished! ===");
                Console.WriteLine($"Your final score: {student.Score}/{maxScore}");
            }
        }
    }
}
