﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project
{
    internal class QuestionList
    {
        private List<Question> questions = new List<Question>();
        private string LogFile;

        public QuestionList(string logFilePath)
        {
            LogFile = logFilePath;
        }

        public QuestionList() : this("QuestionLog.txt") { }

        public void Add(Question q)
        {
            questions.Add(q);
            LogQuestion(q);
        }

        public Question this[int index] => questions[index];
        public int Count => questions.Count;

        private void LogQuestion(Question q)
        {
            using (StreamWriter sw = new StreamWriter(LogFile, true))
            {
                sw.WriteLine($"{DateTime.Now}: Added Question {q}");
            }
        }

        public override string ToString()
        {
            return string.Join(Environment.NewLine, questions);
        }
    }
}
