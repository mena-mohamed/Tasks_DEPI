﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project
{
    internal class ChooseAllQuestion : Question
    {
        public List<int> CorrectIndices { get; set; }

        public ChooseAllQuestion(string header, string body, int marks, List<string> options, List<int> correctIndices)
            : base(header, body, marks)
        {
            CorrectIndices = correctIndices;
            for (int i = 0; i < options.Count; i++)
            {
                bool isCorrect = CorrectIndices.Contains(i);
                Answers.Add(new Answer(QuestionId, options[i], isCorrect));
            }
        }

        public ChooseAllQuestion(string header, string body, int marks, List<string> options)
            : this(header, body, marks, options, new List<int> { 0 }) { }

        public ChooseAllQuestion() : this("No Header", "No Body", 0, new List<string> { "Option1" }) { }

        public override void DisplayQuestion()
        {
            Console.WriteLine($"{Header}: {Body} (Choose All That Apply)");
            for (int i = 0; i < Answers.Count; i++)
                Console.WriteLine($"{i + 1}. {Answers[i].AnswerText}");
        }

        public override bool CheckAnswer(string studentAnswer)
        {
            var parts = studentAnswer.Split(',', StringSplitOptions.RemoveEmptyEntries);
            List<int> chosen = new List<int>();
            foreach (var p in parts)
            {
                if (int.TryParse(p.Trim(), out int index))
                    chosen.Add(index - 1);

            }

            return chosen.Count == CorrectIndices.Count && !chosen.Except(CorrectIndices).Any();
            
        }
    }

}
