﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project
{
    internal class TrueFalseQuestion : Question
    {
        public bool CorrectAnswer { get; set; }

        public TrueFalseQuestion(string header, string body, int marks, bool correctAnswer)
            : base(header, body, marks)
        {
            CorrectAnswer = correctAnswer;
            Answers.Add(new Answer(QuestionId, "True", correctAnswer));
            Answers.Add(new Answer(QuestionId, "False", !correctAnswer));
        }

        public TrueFalseQuestion(string header, string body) : this(header, body, 5, true) { }
        public TrueFalseQuestion() : this("No Header", "No Body", 5, true) { }

        public override void DisplayQuestion()
        {
            Console.WriteLine($"{Header}: {Body} (True/False or true/false or 1/2)");
            Console.WriteLine("1. True");
            Console.WriteLine("2. False");
        }

        public override bool CheckAnswer(string studentAnswer)
        {
            if (string.IsNullOrWhiteSpace(studentAnswer)) return false;

            string ans = studentAnswer.Trim().ToLower();
            if (ans == "true" || ans == "1") return CorrectAnswer;
            if (ans == "false" || ans == "2") return !CorrectAnswer;

            return false;
        }


    }
}
