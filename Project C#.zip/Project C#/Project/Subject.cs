﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project
{
    internal class Subject
    {
        public string SubjName { get; set; }
        public string SubjCode { get; set; }

        public Subject(string name, string code)
        {
            SubjName = name;
            SubjCode = code;
        }

        public Subject() : this("No Subject", "000") { }

        public override string ToString()
        {
            return $"Subject: {SubjName}, SubjectCode: {SubjCode}";
        }
    }
}
