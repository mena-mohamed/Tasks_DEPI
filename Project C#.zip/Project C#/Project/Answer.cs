﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project
{
    public class Answer
    {
        public int QuestionId { get; set; }
        public string AnswerText { get; set; }
        public bool IsCorrect { get; set; }

        public Answer(int questionId, string answerText, bool isCorrect = false)
        {
            QuestionId = questionId;
            AnswerText = answerText;
            IsCorrect = isCorrect;
        }

        public override string ToString()
        {
            return $"{AnswerText} {(IsCorrect ? "(Correct)" : "")}";
        }
    }
}
