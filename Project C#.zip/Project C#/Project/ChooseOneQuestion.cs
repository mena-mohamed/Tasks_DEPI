﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project
{
    internal class ChooseOneQuestion : Question
    {
        public int CorrectIndex { get; set; }

        public ChooseOneQuestion(string header, string body, int marks, List<string> options, int correctIndex)
            : base(header, body, marks)
        {
            CorrectIndex = correctIndex;
            for (int i = 0; i < options.Count; i++)
                Answers.Add(new Answer(QuestionId, options[i], i == CorrectIndex));
        }

        public ChooseOneQuestion(string header, string body, List<string> options)
            : this(header, body, 5, options, 0) { }

        public ChooseOneQuestion() : this("No Header", "No Body", new List<string> { "Option1" }) { }

        public override void DisplayQuestion()
        {
            Console.WriteLine($"{Header}: {Body} (Choose number)");
            for (int i = 0; i < Answers.Count; i++)
                Console.WriteLine($"{i + 1}. {Answers[i].AnswerText}");
            Console.WriteLine("Enter the number of your choice:");
        }

        public override bool CheckAnswer(string studentAnswer)
        {
            if (int.TryParse(studentAnswer.Trim(), out int selected))
                return selected - 1 == CorrectIndex;
            return false;
        }
    }
}
