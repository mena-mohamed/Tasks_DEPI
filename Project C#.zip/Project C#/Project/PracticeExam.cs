﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project
{
    internal class PracticeExam : Exam
    {
        public PracticeExam(Subject subject, int time, string questionLogFile) : base(subject, time, questionLogFile) { }
        public PracticeExam(Subject subject, int time) : base(subject, time, "PracticeQuestions.txt") { }
        public PracticeExam() : this(new Subject(), 30, "PracticeQuestions.txt") { }

        public override void ShowExam(List<Student> students)
        {
            int maxScore = 0;
            for (int i = 0; i < Questions.Count; i++)
                maxScore += Questions[i].Marks;

            foreach (var student in students)
            {
                Console.WriteLine($"\n=== Student: {student.Name} ===");
                student.Score = 0;

                for (int i = 0; i < Questions.Count; i++)
                {
                    var q = Questions[i];
                    q.DisplayQuestion();
                    Console.Write("Your Answer: ");
                    string ans = Console.ReadLine();

                    bool correct = q.CheckAnswer(ans);
                    if (correct) student.Score += q.Marks;

                    Console.WriteLine(correct ? "Correct!" : "Wrong!");

                    Console.WriteLine("Correct Answer(s):");
                    for (int j = 0; j < q.Answers.Count; j++)
                        if (q.Answers[j].IsCorrect)
                            Console.WriteLine($"{j + 1}. {q.Answers[j].AnswerText}");

                    Console.WriteLine("-----------------------------");
                }

                Console.WriteLine($"\n=== Exam Finished! ===");
                Console.WriteLine($"Your final score: {student.Score}/{maxScore}");
            }


        }
    }
}
