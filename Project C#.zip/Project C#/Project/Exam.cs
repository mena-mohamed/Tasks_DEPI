﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project
{
    public delegate void NotifyStudent(string message);

    internal abstract class Exam : ICloneable, IComparable<Exam>
    {
        public enum ExamMode { Queued, Starting, Finished }

        public Subject ExamSubject { get; set; }
        public int Time { get; set; }
        public QuestionList Questions { get; set; }
        public ExamMode Mode { get; set; }

        public Dictionary<int, AnswerList> QuestionAnswerDictionary { get; set; }
        public event NotifyStudent ExamStarted;

        public Exam(Subject subject, int time, string questionLogFile)
        {
            ExamSubject = subject;
            Time = time;
            Questions = new QuestionList(questionLogFile);
            QuestionAnswerDictionary = new Dictionary<int, AnswerList>();
        }

        public Exam(Subject subject, int time) : this(subject, time, "ExamQuestions.txt") { }
        public Exam() : this(new Subject(), 60, "ExamQuestions.txt") { }

        public void AddQuestion(Question q)
        {
            Questions.Add(q);
            QuestionAnswerDictionary[q.QuestionId] = q.Answers;
        }

        public void StartExam(List<Student> students)
        {
            Mode = ExamMode.Starting;
            ExamStarted?.Invoke($"Exam on {ExamSubject.SubjName} is starting!");
            ShowExam(students);
            Mode = ExamMode.Finished;
        }

        public abstract void ShowExam(List<Student> students);

        public object Clone() => this.MemberwiseClone();
        public int CompareTo(Exam other) => this.Time.CompareTo(other.Time);

        public override string ToString()
        {
            return $"{ExamSubject},/n Time: {Time} mins, Questions: {Questions.Count},/n Mode: {Mode}";
        }

        public override bool Equals(object obj)
        {
            if (obj is Exam ex)
                return this.ExamSubject.SubjCode == ex.ExamSubject.SubjCode && this.Time == ex.Time;
            return false;
        }

        public override int GetHashCode() => ExamSubject.SubjCode.GetHashCode() + Time.GetHashCode();
    }
}
