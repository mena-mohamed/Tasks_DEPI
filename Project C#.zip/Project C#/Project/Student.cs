﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project
{
    internal class Student
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public int Score { get; set; } = 0;

        public Student(string id, string name, int score)
        {
            Id = id;
            Name = name;
            Score = score;
        }

        public Student(string id, string name) : this(id, name, 0) { }
        public Student() : this("00", "No Name", 0) { }

        public void ReceiveNotification(string message)
        {
            Console.WriteLine($"Notification: {message}, {Name}");
        }
    }

}
