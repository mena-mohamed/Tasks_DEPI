﻿using System;
using System.Collections.Generic;

namespace Project
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("                              =========== Welcome to the Examination Platform =========");
            Console.WriteLine("\n ");
            Console.Write("Enter your name: ");
            string studentName = Console.ReadLine();

            Console.Write("Enter your ID: ");
            string studentID = Console.ReadLine();

            Student student = new Student(studentID, studentName);
            List<Student> students = new List<Student> { student };

          
            Subject subject = new Subject("C# Programming", "CS101");

         
            PracticeExam practiceExam = new PracticeExam(subject, 30, "PracticeQuestions.txt");
            FinalExam finalExam = new FinalExam(subject, 45, "FinalQuestions.txt");

            practiceExam.AddQuestion(new TrueFalseQuestion("Q1", "Class cannot contain methods, only properties?", 5, false));
            practiceExam.AddQuestion(new ChooseOneQuestion("Q2", "Select correct keyword", 5,
                new List<string> { "class", "interface", "package" }, 0));

            finalExam.AddQuestion(new TrueFalseQuestion("Q1", "Every object must belong to a class?", 5, true));
            finalExam.AddQuestion(new ChooseOneQuestion("Q2", "Select access modifier", 5,
                new List<string> { "class", "private", "method" }, 1));

            practiceExam.ExamStarted += student.ReceiveNotification;
            finalExam.ExamStarted += student.ReceiveNotification;

            
            Console.WriteLine("\nSelect Exam Type: 1. Practice Exam  2. Final Exam");
            string choice = Console.ReadLine();

            Exam selectedExam = choice == "1" ? (Exam)practiceExam : (Exam)finalExam;

            Console.WriteLine($"\nExam created: {selectedExam}");
            Console.WriteLine($"Current Mode: {selectedExam.Mode}");

           
            selectedExam.StartExam(students);

            Console.WriteLine("\n                             ========= Thank you for taking the exam! =========");

        }
    }
}
