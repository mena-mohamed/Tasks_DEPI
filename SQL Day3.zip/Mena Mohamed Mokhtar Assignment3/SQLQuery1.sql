use ITI
--1
insert into Student(St_Id,Dept_Id)
values(17,30)

--2
insert into Instructor(Ins_Id,Salary,Dept_Id)
values(17,4000,30)

--3
update Instructor
set salary *= 1.2;

-----------------------------------------------------------
use MyCompany

--4
select * from employee

--5
select Fname,Lname,Salary,Dno from employee

--6
select Pname,Plocation,Dnum  from Project

--7
select full_name=Fname+' '+Lname , Salary*12*0.10 as "ANNUAL COMM"
from employee

--8
select SSN,Fname,Lname from employee
where Salary > 1000

--9
select SSN,Fname,Lname from employee
where Salary*12 > 10000

--10
select Fname,Lname,Salary from employee
where Sex = 'F'

--11
select Dnum,Dname from Departments
where MGRSSN = 968574

--12
select Pnumber,Pname,Plocation from Project
where Dnum = 10

------------------------------------------------
use ITI
GO
--1
select count(*) from Student
where St_Age is Not NULL

--2
select distinct Ins_Name from Instructor

--3
select I.Ins_Name , D.Dept_Name from Instructor I
Left join Department D
on I.Dept_Id = D.Dept_Id

--4
select St_Fname+' '+St_Lname as "Name" , C.Crs_Name
from Student S
join Stud_Course SC on S.St_Id = SC.St_Id
join Course C on SC.Crs_Id = C.Crs_Id
where SC.Grade is not null

--5
select T.Top_Name , count(C.Crs_Id) as "Num of course" from Topic T
left join Course C on T.Top_Id = C.Top_Id
group by T.Top_Name

--6
select S.St_Fname , I.* from Student S
join Instructor I on S.St_super = I.Ins_Id

--Bouns
select @@VERSION   
select @@SERVERNAME
