﻿using Microsoft.AspNetCore.Mvc;
using MVC_Day2.Data;
using MVC_Day2.Models;
using MVC_Day2.ViewModel;
using System.Data.Entity;
using System.Linq;

namespace MVC_Day2.Controllers
{
    public class DepartmentController : Controller
    {
      
        MvcDbContext context = new MvcDbContext();

        DepartmentBL deptBL = new DepartmentBL();

        public IActionResult Index()
        {
            return View();
        }
        public IActionResult ShowAll()
        {
            var departments = deptBL.GetAll();
            return View(departments);
        }

        public IActionResult ShowDetails(int id)
        {
            var department = deptBL.GetById(id);
         
            if (department == null)
                return NotFound();

            
            var viewmodel = new DepartmentWithExtraInfoViewModel
            {
                DeptName = department.Name,
                StudentsNamesOver25 = department.Students?.Where(s => s.Age > 25)
                                        .Select(s => s.Name)
                                        .ToList() ?? new List<string>(),
                DeptState = (department.Students?.Count ?? 0) > 50 ? "Main" : "Branch"
            };

            return View(viewmodel);
        }

        [HttpGet]
        public IActionResult Add()
        {
            return View();
        }

        [HttpPost]
        public IActionResult SaveAdd(Department DeptSent)
        {
           // if (!string.IsNullOrEmpty(DeptSent.Name))
           if(ModelState.IsValid)
            {
                deptBL.AddDept(DeptSent);
                return RedirectToAction("ShowAll"); 
            }

            return View("Add", DeptSent);
        }
    }
}






