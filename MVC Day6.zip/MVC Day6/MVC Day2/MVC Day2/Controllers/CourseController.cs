﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using MVC_Day2.Data;
using MVC_Day2.Models;
using Microsoft.EntityFrameworkCore;
using System.Linq;
namespace MVC_Day2.Controllers
{
    public class CourseController : Controller
    {
        CourseBL courseBL = new CourseBL();
        DepartmentBL deptBL = new DepartmentBL();

        public IActionResult Index()
        {
            var list = courseBL.GetAll();
            return View(list);
        }
        [HttpGet]
        


        [HttpGet]
        public IActionResult Add()
        {
            ViewBag.DeptList = new SelectList(deptBL.GetAll(), "Id", "Name");
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Add(Course model)
        {
           
            if (model.MinDegree > model.MaxDegree)
                ModelState.AddModelError(nameof(model.MinDegree), "Min degree cannot be greater than Max degree");

            if (ModelState.IsValid)
            {
                courseBL.Add(model);
                return RedirectToAction(nameof(Index));
            }

            ViewBag.DeptList = new SelectList(deptBL.GetAll(), "Id", "Name", model.DepartmentId);
            return View(model);
        }

        [HttpGet]
        public IActionResult Edit(int id)
        {
            var course = courseBL.GetById(id);
            if (course == null) return NotFound();

            ViewBag.DeptList = new SelectList(deptBL.GetAll(), "Id", "Name", course.DepartmentId);
            return View(course);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(Course model)
        {
            if (model.MinDegree > model.MaxDegree)
            {
                ModelState.AddModelError(nameof(model.MinDegree), "Min degree cannot be greater than Max degree");
            }

            if (ModelState.IsValid)
            {
                courseBL.Update(model);
                return RedirectToAction(nameof(Index));
            }

            ViewBag.DeptList = new SelectList(deptBL.GetAll(), "Id", "Name", model.DepartmentId);
            return View(model);
        }

        [HttpGet]
        public IActionResult ShowDetails(int id)
        {
            var course = courseBL.GetById(id);
            if (course == null) return NotFound();
            return View(course);
        }

        [HttpGet]
        public IActionResult Delete(int id)
        {
            var course = courseBL.GetById(id);
            if (course == null) return NotFound();
            return View("WarningDelete", course);
        }

        [HttpPost, ActionName("ConfirmDelete")]
        [ValidateAntiForgeryToken]
        public IActionResult ConfirmDelete(int id)
        {
            // prevent deletion if there are student results linked
            using var ctx = new MvcDbContext();
            if (ctx.StuCrsRes.Any(sr => sr.CourseId == id))
            {
                TempData["Error"] = "Cannot delete course because there are student results linked to it.";
                return RedirectToAction(nameof(Index));
            }

            courseBL.Delete(id);
            return RedirectToAction(nameof(Index));
        }
    }
}
