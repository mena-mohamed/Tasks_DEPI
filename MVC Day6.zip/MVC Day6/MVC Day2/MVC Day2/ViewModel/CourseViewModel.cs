﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System.ComponentModel.DataAnnotations;

namespace MVC_Day2.ViewModel
{
    public class CourseViewModel
    {
        [Required(ErrorMessage = "Course name is required")]
        [StringLength(100, MinimumLength = 3, ErrorMessage = "Name must be between 3 : 100")]
        public int Id { get; set; }

        public string Name { get; set; }

        [Range(0, 1000)]
        public int MaxDegree{ get; set; }

        [Range(0, 1000)]
        public int MinDegree { get; set; }

        [Required]
        public int DepartmentId { get; set; }

        public List<SelectListItem> Departments { get; set; }
    }
}
