﻿using System.ComponentModel.DataAnnotations;

namespace MVC_Day2.Models
{
    public class Student
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Name is required")]
        [MaxLength(30, ErrorMessage = "Less than 30")]
        [MinLength(3, ErrorMessage = "More than 3")]
        [RegularExpression(@"^[a-zA-Z\s]+$", ErrorMessage = "contains only letters and spaces")]
        public string? Name { get; set; }

        [Range(18, 30, ErrorMessage = "between 18 and 30")]
        public int Age { get; set; }

        [Display(Name = "Department")]
        [Required(ErrorMessage = "Required")]
        [Range(1, int.MaxValue, ErrorMessage = "Enter valid department")]
        public int DepartmentId { get; set; }
        public Department Department { get; set; }
        public List<StuCrsRes> StuCrsRes { get; set; }

    }
}
