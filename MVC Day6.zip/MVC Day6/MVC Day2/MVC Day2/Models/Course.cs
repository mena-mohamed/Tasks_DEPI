﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace MVC_Day2.Models
{
    public class Course
    {
        
        public int Id { get; set; }
        [Required(ErrorMessage = "Course name is required")]
        [StringLength(100, MinimumLength =3, ErrorMessage ="Name must be between 3 : 100")]
        public string Name { get; set; }
    
        [DisplayName( "Maximum Degree")]
        [Range(0, 1000, ErrorMessage ="Enter a valid maximum degree")]
        public int MaxDegree { get; set; }

        [Display(Name = "Maximum Degree")]
        [Range(0, 1000, ErrorMessage = "Enter a valid minimum degree")]
        public int MinDegree { get; set; }

     
        [Range(1, int.MaxValue, ErrorMessage ="Enter valid department")]
        public int DepartmentId { get; set; }
      
        public Department Department { get; set; }
        public List<Teacher> Teachers { get; set; }
        public List<StuCrsRes> StuCrsRes { get; set; }


    }
}
