﻿using MVC_Day2.Data;
using System.Data.Entity;

namespace MVC_Day2.Models
{
    public class CourseBL
    {
        MvcDbContext context = new MvcDbContext();

        public List<Course> GetAll()
        {
            return context.Courses.Include(c => c.Department).ToList();
        }

        public Course GetById(int id)
        {
            return context.Courses.Include(c => c.Department).FirstOrDefault(c => c.Id == id);
        }

        public void Add(Course course)
        {
            context.Courses.Add(course);
            context.SaveChanges();
        }

        public void Update(Course course)
        {
            context.Courses.Update(course);
            context.SaveChanges();
        }

        public void Delete(int id)
        {
            var cour = GetById(id);
            if (cour != null)
            {
                context.Courses.Remove(cour);
                context.SaveChanges();
            }
        }
    }
}

