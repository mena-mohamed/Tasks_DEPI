
--(1) Create a stored procedure to show the number of students per department.[use ITI DB] 

use ITI

create or alter proc SP_GetNoStudents @dept_id int
as
 select count(*),Dept_Id
 from Student 
 where Dept_Id = @dept_id
 group by Dept_Id


 SP_GetNoStudents 10


 --(2)Create a stored procedure that will check for the Number of employees in the project p1 if they are more than 3 print message to the user �'The 
----number of employees in the project p1 is 3 or more'� if they are less display a message to the user �'The following employees work for the project p1'� 
----in addition to the first name and last name of each one. [MyCompany DB]  

use MyCompany
GO
create or alter proc SP_GetDataOfEmployees @pnum int
as

  declare @emp_count int
  select @emp_count = count(*)
  from Works_for W
  where W.Pno = @pnum

  if @emp_count > 3
     begin
	      select 'The number of employees in the project p1 is 3 or more'
	 end
  else 
     begin
           print 'The following employees work for the project p1'
		   select E.Fname,E.Lname
		   from Employee E join Works_for W
		   on E.SSN = W.ESSN
		   where W.Pno = @pnum
      end

EXEC SP_GetDataOfEmployees 700

--(3)Create a stored procedure that will be used in case there is an old employee has left the project and a new one become instead of him. The 
---procedure should take 3 parameters (old Emp. number, new Emp. number and the project number) and it will be used to update works_on table. [MyCompany DB]

use MyCompany

create or alter proc SP_ReplaceEmpOnProject @old_emp int,@new_emp int,@projnum int
as
begin
    if not exists(
	      select 1 from Works_for
          where ESSN = @new_emp  and Pno = @projnum
    )
	begin
	  update Works_for 
	  set ESSN = @new_emp 
	  where ESSN = @old_emp and Pno = @projnum
	end
	
	else 
	begin 
	  delete from Works_for
	  where ESSN = @old_emp and Pno = @projnum
	end
end

SP_ReplaceEmpOnProject 669955,669955 ,30
select * from Works_for

